(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Image = function() {
	this.initialize(img.Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2101,1319);


(lib.Path = function() {
	this.initialize(img.Path);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,37,376);


(lib.Path_0 = function() {
	this.initialize(img.Path_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,25,252);


(lib.Path_1 = function() {
	this.initialize(img.Path_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,35,187);


(lib.Path_2 = function() {
	this.initialize(img.Path_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,23,236);


(lib.Path_3 = function() {
	this.initialize(img.Path_3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,429,595);


(lib.Path_4 = function() {
	this.initialize(img.Path_4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,121,228);


(lib.Path_5 = function() {
	this.initialize(img.Path_5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,73,430);


(lib.Path_6 = function() {
	this.initialize(img.Path_6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,27,100);


(lib.Path_7 = function() {
	this.initialize(img.Path_7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,271,108);


(lib.Path_8 = function() {
	this.initialize(img.Path_8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,154,190);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AksiXIAJgmIJQFVIgJAmg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30,-19,60.1,38.1);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#22B2DF","rgba(0,68,127,0.976)","#012060","#000C34","#00447F"],[0,1,1,1,1],-51.6,-62.2,58.7,71.5).s().p("AHyLnIyaqoQgPgKADgSICdr3QAAgEADgEQAFgKAKgCQALgDAJAFISZKoQAIAFADAHQAEAIgCAIIidL3IgCAIIgBAAQgFAJgKADIgHABQgHAAgGgDg");
	this.shape.setTransform(0.0185,0.0137);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.3,-74.6,138.7,149.3);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#22B2DF","rgba(0,68,127,0.976)","#012060","#000C34","#00447F"],[0,1,1,1,1],-51.6,-62.2,58.7,71.5).s().p("AHyLnIyaqoQgPgKADgSICdr3QAAgEADgEQAFgKAKgCQALgDAJAFISZKoQAIAFADAHQAEAIgCAIIidL3IgCAIIgBAAQgFAJgKADIgHABQgHAAgGgDg");
	this.shape.setTransform(0.0185,0.0137);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.3,-74.6,138.7,149.3);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// linie_Brana
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#15FF5F").ss(1,1,1).p("ADMCrIgehPIg1AZIg0iyIhFA8IgehGIhGBNIgViYIgoBUIgRheIgZgO");
	this.shape.setTransform(-4.025,0.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAUBUIAkhFIAZCJIBChBIAfA9IBBgsIA4ChIAzgOIAgBM");
	this.shape_1.setTransform(-4.025,0.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAWBLIAhg3IAdB6IA+g0IAgAyIA9gcIA8CQIAwgBIAjBI");
	this.shape_2.setTransform(-4.025,0.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAYBBIAdgoIAiBrIA6goIAhApIA6gNIA/B/IAuALIAlBF");
	this.shape_3.setTransform(-4.025,0.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAbA3IAZgaIAmBcIA2gbIAiAgIA2ADIBDBtIArAXIAoBC");
	this.shape_4.setTransform(-4.025,0.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAdAtIAVgLIArBNIAygPIAiAWIAzATIBHBdIApAiIAqA/");
	this.shape_5.setTransform(-4.025,0.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAfAkIASADIAvA+IAtgCIAkAMIAvAiIBLBMIBTBq");
	this.shape_6.setTransform(-4.025,0.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAhAaIAPASIAzAuIApALIAlACIAsAzIBOA6IAjA7IAwA4");
	this.shape_7.setTransform(-4.025,0.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIA9AeIAKAgIBdA3IAmgHIAoBBIBSAqIAhBHIAyA1");
	this.shape_8.setTransform(-4.025,0.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAmAGIAHAvIA8AQIAhAkIAngQIAkBRIBWAZIAeBSIA1Ay");
	this.shape_9.setTransform(-4.025,0.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAogDIAEA9IBAABIAdAxIAngbIAhBhIBaAIIAcBeIA3Av");
	this.shape_10.setTransform(-4.025,0.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIArgNIgBBMIBFgOIAZA9IAogkIAeBwIBdgJIAZBqIA6As");
	this.shape_11.setTransform(-4.025,0.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIApgEIACA+IBCAAIAcAyIAngbIAhBiIBaAGIAcBfIA3Av");
	this.shape_12.setTransform(-4.025,0.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAmAFIAHAxIA9AOIAgAmIAngTIAkBUIBWAWIAeBUIA1Ay");
	this.shape_13.setTransform(-4.025,0.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAkAOIAKAkIA5AbIAkAbIAmgKIAnBFIBTAmIAgBKIAzA0");
	this.shape_14.setTransform(-4.025,0.075);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIA7AlIANAWIA1AqIAoAPIAlgBIAqA3IBQA1IAjA/IAwA3");
	this.shape_15.setTransform(-4.025,0.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAgAgIARAJIAwA3IAsAEIAkAIIB6BtIBTBu");
	this.shape_16.setTransform(-4.025,0.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAeApIAUgEIAtBFIAvgIIBUArIBwB9IAsA9");
	this.shape_17.setTransform(-4.025,0.075);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAcAxIAXgRIApBTIAzgUIAiAaIA1ANIBFBjIAqAeIApBA");
	this.shape_18.setTransform(-4.025,0.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAaA6IAageIAlBhIA3ggIAiAjIA3gCIBCBzIAsATIAnBD");
	this.shape_19.setTransform(-4.025,0.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAYBDIAegsIAhBvIA6grIAhAsIA7gRIA+CDIAuAIIAlBG");
	this.shape_20.setTransform(-4.025,0.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIAWBMIAhg5IAdB9IA+g3IAgA1IA+gfIA7CSIAxgDIAiBJ");
	this.shape_21.setTransform(-4.025,0.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#15FF5F").ss(1,1,1).p("AjLiqIAZAOIATBVIAlhGIAZCKIBChCIAfA9IBBgtIA4CiIAzgOIAgBM");
	this.shape_22.setTransform(-4.025,0.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.4,-18,42.8,36.2);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDF7FB").s().p("AhKAcIAAg3IAlAAIAAAiIBwAAIAAAVg");
	this.shape.setTransform(5.1143,3.4089,0.2617,0.2617);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1A6CBE").s().p("AinBiQgeg2Akg4QAggyBMgqICVAyIBWBVQhJAshWATQg0ALg1AAQgrAAgqgHg");
	this.shape_1.setTransform(5.441,3.2303,0.2617,0.2617);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00EDF9").s().p("Ai+BvQgmg+AphAQAlg6BagvICqA5IBjBiQhZA4hoAUQgyAKgzAAQg0AAg1gKg");
	this.shape_2.setTransform(5.5377,3.1685,0.2617,0.2617);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#102465").s().p("AigA/IgBAAIgdgFQgRgbgBghIAAgyQABAiARAaIA6AJIBQgBIAQgBIAFAAIASgCIACAAIASgDIAUgEIABAAIBWgZIAbgLIAEgCIAKgEIArgYIALgGIAAAyIgLAHIhEAhIgRAHIgfALIgSAGIgBAAIgjAIIgBAAIgRAEIgDAAIgTADIgBAAIgTACIgEAAIgQABIhBABg");
	this.shape_3.setTransform(5.5087,5.8711,0.2618,0.2618);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,11,7.6), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDF7FB").s().p("AiMA2IgBhrIBFAAIAABDIDWAAIAAAog");
	this.shape.setTransform(12.7086,8.5332,0.3472,0.3472);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1A6CBE").s().p("Ak9C5Qg5hmBFhqQA9hgCOhPIEaBeICkCjQiOBVifAhQhjAWhkAAQhRAAhQgOg");
	this.shape_1.setTransform(13.5413,8.0683,0.3472,0.3472);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00EDF9").s().p("AlnDRQhJh1BOh6QBGhuCqhYIFDBsIC6C6QiYBji9ApQhtAXhsAAQhjAAhhgUg");
	this.shape_2.setTransform(13.7192,7.963,0.3472,0.3472);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#102465").s().p("Aj6B9Ig0gGIgCAAIg3gJIgBAAQgig1gBg9IAAhZQACA7AhAxIBEALICJAIIA6gBIBIgIIADAAIAkgFIAHgCIAggGIACAAIBCgPIBcgfIA9gZIBkg1IAWgPIAABfIhGAnIg0AaIh4AuIhFAUIgeAGIgCAAIhLAOIgDAAIgnAEIgDAAIgeADIgBAAIgdACg");
	this.shape_3.setTransform(13.7329,14.6531,0.3472,0.3472);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,27.5,19.1), null);


(lib.Path2367 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(147,255,253,0)","rgba(149,254,253,0.067)","rgba(154,253,253,0.247)","rgba(163,252,254,0.549)","rgba(176,251,254,0.937)","#B2FBFF"],[0.039,0.141,0.329,0.612,0.949,1],25.1,-95.9,-55.7,56.9).s().p("AorPyMgFLgklIbtAAMgFLAklIorFCg");
	this.shape.setTransform(88.675,133.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2367, new cjs.Rectangle(0,0,177.4,266.3), null);


(lib.Path2392 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(147,255,253,0)","rgba(149,254,253,0.067)","rgba(154,253,253,0.247)","rgba(163,252,254,0.549)","rgba(176,251,254,0.937)","#B2FBFF"],[0.039,0.141,0.329,0.612,0.949,1],-1.4,-50.1,-6.3,68.5).s().p("AjuOeIlmjPQgPgGgEgQQg5lig6l9Qhzr6gCiIIafAAQhBIDiENkQgBASgSAJIsJHEQgVALgZAAQgZAAgWgLg");
	this.shape.setTransform(84.775,93.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2392, new cjs.Rectangle(0,0,169.6,187.4), null);


(lib.Path2408 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(147,255,253,0)","rgba(149,254,253,0.067)","rgba(154,253,253,0.247)","rgba(163,252,254,0.549)","rgba(176,251,254,0.937)","#B2FBFF"],[0.039,0.141,0.329,0.612,0.949,1],0,-69.1,0,46).s().p("As2KYIAA8LIZtAAIAAcLIs1Hcg");
	this.shape.setTransform(82.25,114.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2408, new cjs.Rectangle(0,0,164.5,228.1), null);


(lib.Path2351 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(147,255,253,0)","rgba(149,254,253,0.067)","rgba(154,253,253,0.247)","rgba(163,252,254,0.549)","rgba(176,251,254,0.937)","#B2FBFF"],[0.039,0.141,0.329,0.612,0.949,1],8.4,-31.2,-17.6,17.5).s().p("AixFDIhprrII1AAIhqLrIixBmg");
	this.shape.setTransform(28.325,42.525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2351, new cjs.Rectangle(0,0,56.7,85.1), null);


(lib.Path2337 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(147,255,253,0)","rgba(149,254,253,0.067)","rgba(154,253,253,0.247)","rgba(163,252,254,0.549)","rgba(176,251,254,0.937)","#B2FBFF"],[0.039,0.141,0.329,0.612,0.949,1],15.1,-56.3,-34.5,35.5).s().p("AlOJiIjI2FIQtAAIjIWFIlODCg");
	this.shape.setTransform(53.525,80.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2337, new cjs.Rectangle(0,0,107.1,160.9), null);


(lib.Path2256 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(147,255,253,0)","rgba(149,254,253,0.067)","rgba(154,253,253,0.247)","rgba(163,252,254,0.549)","rgba(176,251,254,0.937)","#B2FBFF"],[0.039,0.141,0.329,0.612,0.949,1],-0.1,-9.1,-0.8,15.9).s().p("AhTEPIhTpPIFMgBIhIJQIhZAzg");
	this.shape.setTransform(16.65,32.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2256, new cjs.Rectangle(0,0,33.3,64.4), null);


(lib.Path2323 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("Ai4goIAAiDIFwDVIAAAAIAACBg");
	this.shape.setTransform(18.45,17.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2323, new cjs.Rectangle(0,0,36.9,34.3), null);


(lib.Path2329 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("ABcAiIiKBPIhEh1IhEAmIABjgIFsDRIgBCrgAhCgkQgKAFAAAPQACAjAeAVQANAIALgGQAJgFAAgQQgCgjgfgVQgHgEgHAAQgEAAgEADg");
	this.shape.setTransform(18.25,19.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2329, new cjs.Rectangle(0,0,36.5,38.1), null);


(lib.Path2322 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("AkpAFIABlfIJRFXIgBFeg");
	this.shape.setTransform(29.75,34.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2322, new cjs.Rectangle(0,0,59.5,69.4), null);


(lib.Path2328 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B8FFFF").s().p("Agtg8IAAAAIBbBxIhbAIg");
	this.shape.setTransform(4.625,6.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2328, new cjs.Rectangle(0,0,9.3,12.3), null);


(lib.Path2327 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("AAACnQg7gigrhKQgqhIgBhGQABhFArgYQArgZA6AjIAAAAQA8AjArBJQAqBJAABFQAABGgqAYQgSAKgVAAQgdAAgjgVgAgkAoIBbgIIhbhxg");
	this.shape.setTransform(14.55,18.6836);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2327, new cjs.Rectangle(0,0,29.1,37.5), null);


(lib.Path2324 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("Ag4AhIAAiCIBxBCIAACBg");
	this.shape.setTransform(5.675,9.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2324, new cjs.Rectangle(0,0,11.4,19.6), null);


(lib.Path2325 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("Ak/AGIABl8IJ+FxIgBF8gAEXESQgJgngRgsQgghVgngXQgbgPgeAYQgfAZgOgHQgPgJgPg1QgPg0gPgIQgLgIgUAdQgVAegZgPQgXgNgghTQghhUgggSQglgWgkBHQgTAlgKAoIIuFCIAAAAg");
	this.shape.setTransform(32,37.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2325, new cjs.Rectangle(0,0,64,75), null);


(lib.Path2306 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00EDF9").s().p("Ai9DQQgEgCAAgFIAAiyQAAgMALgHIFsjSIAAgBQAFgCADACQADACABAFIAACyQgBAMgKAHIltDTIgFABIgCgBgAg+BaIgVAMQgEACgBAGQABAFAEgCIAVgMQAFgEAAgFQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAAAAAIgDABgAgVBCIgVAMQgEACAAAGQAAABAAAAQAAABAAAAQAAAAAAABQABAAAAAAIADAAIAVgMQAFgDAAgFQAAgBAAgBQAAgBgBAAQAAgBAAAAQgBAAAAAAIgDABgABfgoIiyBmQgEADgBAGQAAAAAAABQAAAAAAAAQABABAAAAQAAAAAAABQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABgBICyhmQAFgDAAgFQAAgBAAgBQAAgBgBAAQAAgBAAAAQgBAAAAAAIgDABgAiSANQgOAJgBAQQAAAHAFACQADADAHgEQANgJABgPQAAgHgEgDIgEgBQgDAAgDACgAARgiIhkA5QgEADgBAFQAAABAAAAQAAABAAAAQABABAAAAQAAAAAAAAQABABAAAAQABAAAAAAQABAAAAAAQAAAAABgBIABAAIBjg5QADgDABgFQAAgBAAgBQAAgBAAAAQAAgBgBAAQAAAAgBAAIgCABgABYhyIiqBjQgGADAAAFQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAQAAAAABABQAAAAABAAQAAAAABgBQAAAAABAAICqhjQAEgDAAgFQAAgBAAAAQAAgBAAAAQgBAAAAAAQAAgBgBAAIgBAAIgBAAgAAzg1IgNAHQgEADgBAFQAAABAAAAQAAABAAAAQABABAAAAQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAQABAAAAgBIANgHQADgDABgGQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAAAgBAAIgCABgACahxIhSAvQgEADAAAFQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAQAAAAABAAQAAAAAAgBIBSgvQAFgDABgGQAAAAgBgBQAAAAAAAAQAAgBAAAAQgBAAAAAAIgCgBIgCABgACaiZIguAbQgEACAAAGQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAAAABAAQAAAAABgBQAAAAAAAAIAugbQAFgCABgGQAAAAgBgBQAAAAAAAAQAAgBAAAAQgBAAAAgBIgCAAIgCAAg");
	this.shape.setTransform(19.4,20.925);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2306, new cjs.Rectangle(0,0,38.8,41.9), null);


(lib.Path2304 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00EDF9").s().p("Ak/GeQgFgCAAgIIgBmwQAAgRAPgJIJrlmQAGgDAFACQAFADgBAHIABGwQAAARgOAJIprFmQgEACgDAAIgEgBgAhvALQgfAUgCAlQAAAHAEAIIhEB6QgIABgHAEQgOAJgJAPQgIAPgBARQAAAQAKAFQAJAGANgIQAfgUACgkQAAgKgEgGIBFh6QAHAAAHgEQAHgFAHgHIBFAqQgDAJAAALQAAAQAKAFQAKAFAMgHQAegUADglQAAgKgHgIIBLieQAFgBAFgDQAegUADglIAAgEIA4hBQAMAGALgIQAPgJAJgPQAIgPABgRQAAgQgJgFQgKgFgOAHQgeAUgDAlIAAAEIg4BBIAAgBQgMgFgLAIQgfAUgBAkQgCALAIAHIhMCeIgKAEQgGAFgGAHIhGgqQADgIABgMQgBgPgJgGQgEgCgFAAQgGAAgIAEg");
	this.shape.setTransform(32.55,41.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2304, new cjs.Rectangle(0,0,65.1,83), null);


(lib.Path2393 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00EDF9").s().p("AkYIpQgIgEAAgMIgCriQACgdAYgQIIPkwIgBAAQALgHAIAFQAIAEgBAMIADLjQgCAcgYAQIoPExQgGADgFAAQgEAAgDgCgAiEFVIhKArQgIAFgBALQAAAEADABQADACADgCIBKgrQAIgFABgLQAAgEgDgBIgCgBIgEABgAgcDtIiyBnQgJAFAAALQAAAEADABQADACADgCICyhnQAIgFABgLQAAgEgCgBIgDgBIgEABgAA9ERIgsAaQgJAFAAAKQAAAFACABQADACAEgCIAsgaQAJgGAAgKQABgEgDgCIgCAAIgFABgAiXEIIg3AgQgJAGAAAKQAAAEADABQADACADgCIA3ggQAJgGAAgJQAAgFgDgBIgCgBIgEABgABqBzIAACZIABAAIBrg+IAAiZgAA9CNIixBnQgJAGAAAKQAAAEADABQADACADgCICxhnQAIgFABgLQAAgEgCgBIgDgBIgEABgAA9C5Ig3AgQgIAFAAAKQABAFABABQADACADgCIA3ggQAJgFAAgLQAAgEgCgBIgDgBIgEABgAh5CfIhVAxQgIAFgBALQAAAEADACQACABAEgCIBVgxQAIgFABgLQAAgEgDgBIgCgBIgEABgAB9gaIlLC+QgJAGAAAKQAAAEADACQADACADgDIFLi/QAIgFABgKQAAgEgCgCIgDAAIgEABgAA1gdIkDCVQgJAGAAAKQAAAEADACQADABADgCIEDiVQAIgFABgKQAAgFgCgBIgDgBIgEABgADMigImbDtQgIAFgBALQAAAEACABQAEACADgCIAAgBIGbjsQAIgFABgLQAAgEgCgCIgDAAIgEABgAjVjAIABDiIGpj2IAAjigADNhIIgtAZQgIAGgBAKQAAAEADACQADABADgCIAAAAIAtgaQAJgFAAgKQAAgEgDgCIgDAAIgDABgADNh0IhwBAQgIAFgBALQAAAEADACQADABADgCIAAABIBwhBQAIgFABgLQAAgEgCgCIgDAAIgEABg");
	this.shape.setTransform(29.05,55.4672);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2393, new cjs.Rectangle(0,0,58.1,111), null);


(lib.Path2393_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00EDF9").s().p("AkYIpQgIgEAAgMIgCriQACgdAYgQIIPkwIgBAAQALgHAIAFQAIAEgBAMIADLjQgCAcgYAQIoPExQgGADgFAAQgEAAgDgCgAiEFVIhKArQgIAFgBALQAAAEADABQADACADgCIBKgrQAIgFABgLQAAgEgDgBIgCgBIgEABgAgcDtIiyBnQgJAFAAALQAAAEADABQADACADgCICyhnQAIgFABgLQAAgEgCgBIgDgBIgEABgAA9ERIgsAaQgJAFAAAKQAAAFACABQADACAEgCIAsgaQAJgGAAgKQABgEgDgCIgCAAIgFABgAiXEIIg3AgQgJAGAAAKQAAAEADABQADACADgCIA3ggQAJgGAAgJQAAgFgDgBIgCgBIgEABgABqBzIAACZIABAAIBrg+IAAiZgAA9CNIixBnQgJAGAAAKQAAAEADABQADACADgCICxhnQAIgFABgLQAAgEgCgBIgDgBIgEABgAA9C5Ig3AgQgIAFAAAKQABAFABABQADACADgCIA3ggQAJgFAAgLQAAgEgCgBIgDgBIgEABgAh5CfIhVAxQgIAFgBALQAAAEADACQACABAEgCIBVgxQAIgFABgLQAAgEgDgBIgCgBIgEABgAB9gaIlLC+QgJAGAAAKQAAAEADACQADACADgDIFLi/QAIgFABgKQAAgEgCgCIgDAAIgEABgAA1gdIkDCVQgJAGAAAKQAAAEADACQADABADgCIEDiVQAIgFABgKQAAgFgCgBIgDgBIgEABgADMigImbDtQgIAFgBALQAAAEACABQAEACADgCIAAgBIGbjsQAIgFABgLQAAgEgCgCIgDAAIgEABgAjVjAIABDiIGpj2IAAjigADNhIIgtAZQgIAGgBAKQAAAEADACQADABADgCIAAAAIAtgaQAJgFAAgKQAAgEgDgCIgDAAIgDABgADNh0IhwBAQgIAFgBALQAAAEADACQADABADgCIAAABIBwhBQAIgFABgLQAAgEgCgCIgDAAIgEABg");
	this.shape_1.setTransform(29.05,55.4672);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path2393_1, new cjs.Rectangle(0,0,58.1,111), null);


(lib.Group4796 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("AgXAVQgDgBAAgFQABgKAJgFIAhgUQAEgCADABQADACgBAEQgBALgIAEIghAUIgFACIgCgBg");
	this.shape.setTransform(37.6,29.4115);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A5FFFF").s().p("AhQA2QgDgCAAgEQABgKAJgFICThWQAEgCADACQADABAAAFQgBAKgJAFIiTBVIgFACIgCgBg");
	this.shape_1.setTransform(25.325,36.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A5FFFF").s().p("AgxAkQgCgBAAgFQAAgKAJgGIBVgxQAEgCADACQACABAAAEQgBALgIAGIhVAxIgFABIgCgBg");
	this.shape_2.setTransform(35,25.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A5FFFF").s().p("AgGALQgDgCABgEIAAgEIAAgCIACgCQADgFADgCIAAAAQAEgCACACIACABIABABIAAACIAAABQAAAFgDADQgCAFgEACIgDACIgDgBg");
	this.shape_3.setTransform(27.8639,29.721);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A5FFFF").s().p("AgqAgQgCgBAAgFQABgLAJgFIBGgpIAAAAQAJgEAAAKQAAAKgJAGIhHAoIgFACIgCgBg");
	this.shape_4.setTransform(21.425,33.3583);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FDF7FB").s().p("AgbAEIA2ggIABAAIAAAaIg3Afg");
	this.shape_5.setTransform(10.5,45.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FDF7FB").s().p("AgbAEIA3ggIAAAaIg3Afg");
	this.shape_6.setTransform(10.45,39.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#A5FFFF").s().p("AgcgtIA5giIAAB9Ig5Aig");
	this.shape_7.setTransform(48.25,39.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#A5FFFF").s().p("AgcgWIA5giIAABPIg5Aig");
	this.shape_8.setTransform(37.2,55.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#A5FFFF").s().p("AgcgdIA5ghIAABcIg5Ahg");
	this.shape_9.setTransform(26.1,59.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#A5FFFF").s().p("AgcgJIA5ghIAAA0Ig5Ahg");
	this.shape_10.setTransform(15.025,73.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FDF7FB").s().p("AgchUIA5ghIAADJIg4Aig");
	this.shape_11.setTransform(48.3,55.75);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FDF7FB").s().p("AgcgvIA5ghIAACAIg5Ahg");
	this.shape_12.setTransform(37.225,65.825);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FDF7FB").s().p("Agcg5IA5giIAACVIg5Aig");
	this.shape_13.setTransform(26.1,71.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FDF7FB").s().p("AgcgZIA5giIAABVIg5Aig");
	this.shape_14.setTransform(15.05,80.825);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#A5FFFF").s().p("AkEDNIgBmUQgBgFAFgDIAAAAQABgBAAAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABIABGPIH9kmQAEgCABAFQgBAFgEADIoCEoIgCABQgBAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBg");
	this.shape_15.setTransform(33.5,74.0279);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00EDF9").s().p("AlAISQgIgFAAgNIgCqBQABgfAbgRIJcleIgBAAQAMgGAIAEQAJAFAAANIABKBQgBAfgbARIpbFeQgHAEgGAAQgEAAgDgCgAj9ABQgFACAAAGIABGVQABAFAEgDIAAABIICkpQAEgDAAgFQAAgGgEADIn9EmIgBmQQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBAAIgBgBIgCABgAjRDFIAACLIA7ghIAAhWIgMAGIALgGIAAg1gAhiB6IAACWIA7giIAAiWgAAMBPIAACBIA7giIAAiBgAB7g6IAADKIA6giIAAjKgAhiAdIAABdIA6giIAAhcgAAMAAIAABPIA6giIAAhPgAj9hNIAAAZIA3ggIAAgZgAB7i4IAAB+IA6giIAAh+gAj9iCIAAAZIAAAAIA4ggIAAgZgAgDjbIiVBWQgIAFgBALQAAAEADACQADACADgDIABAAICUhWQAHgFABgLQAAgEgCgCIgDAAIgDABgAhPjlIhJAqQgIAFgBALQAAAEADACQADABAEgCIBIgpQAJgGAAgKQAAgFgDgBIgCgBIgEABgAA+kCIgiAUQgJAGgBAKQAAAFADABQADACAEgCIAigUQAIgFABgLQAAgFgDgBIgCgBIgEABgAg1j0QgEACgDAEIgCAFIAAAFQAAADADADQADABAEgCIgBAAQAEgCACgFQADgEAAgFIAAgCIgBgDIgCgBIgCgBIgEACgAA+k3IhVAyQgJAFgBALQABAEACACQADABAEgCIBVgyQAJgFAAgLQAAgEgCgCIgDAAIgEABg");
	this.shape_16.setTransform(33.125,53.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group4796, new cjs.Rectangle(0,0,66.3,106.4), null);


(lib.Group4796_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#A5FFFF").s().p("AgXAVQgDgBAAgFQABgKAJgFIAhgUQAEgCADABQADACgBAEQgBALgIAEIghAUIgFACIgCgBg");
	this.shape_17.setTransform(37.6,29.4115);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#A5FFFF").s().p("AhQA2QgDgCAAgEQABgKAJgFICThWQAEgCADACQADABAAAFQgBAKgJAFIiTBVIgFACIgCgBg");
	this.shape_18.setTransform(25.325,36.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#A5FFFF").s().p("AgxAkQgCgBAAgFQAAgKAJgGIBVgxQAEgCADACQACABAAAEQgBALgIAGIhVAxIgFABIgCgBg");
	this.shape_19.setTransform(35,25.575);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#A5FFFF").s().p("AgGALQgDgCABgEIAAgEIAAgCIACgCQADgFADgCIAAAAQAEgCACACIACABIABABIAAACIAAABQAAAFgDADQgCAFgEACIgDACIgDgBg");
	this.shape_20.setTransform(27.8639,29.721);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#A5FFFF").s().p("AgqAgQgCgBAAgFQABgLAJgFIBGgpIAAAAQAJgEAAAKQAAAKgJAGIhHAoIgFACIgCgBg");
	this.shape_21.setTransform(21.425,33.3583);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FDF7FB").s().p("AgbAEIA2ggIABAAIAAAaIg3Afg");
	this.shape_22.setTransform(10.5,45.025);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FDF7FB").s().p("AgbAEIA3ggIAAAaIg3Afg");
	this.shape_23.setTransform(10.45,39.675);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#A5FFFF").s().p("AgcgtIA5giIAAB9Ig5Aig");
	this.shape_24.setTransform(48.25,39.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#A5FFFF").s().p("AgcgWIA5giIAABPIg5Aig");
	this.shape_25.setTransform(37.2,55.425);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#A5FFFF").s().p("AgcgdIA5ghIAABcIg5Ahg");
	this.shape_26.setTransform(26.1,59.025);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#A5FFFF").s().p("AgcgJIA5ghIAAA0Ig5Ahg");
	this.shape_27.setTransform(15.025,73.875);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FDF7FB").s().p("AgchUIA5ghIAADJIg4Aig");
	this.shape_28.setTransform(48.3,55.75);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FDF7FB").s().p("AgcgvIA5ghIAACAIg5Ahg");
	this.shape_29.setTransform(37.225,65.825);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FDF7FB").s().p("Agcg5IA5giIAACVIg5Aig");
	this.shape_30.setTransform(26.1,71.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FDF7FB").s().p("AgcgZIA5giIAABVIg5Aig");
	this.shape_31.setTransform(15.05,80.825);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#A5FFFF").s().p("AkEDNIgBmUQgBgFAFgDIAAAAQABgBAAAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABIABGPIH9kmQAEgCABAFQgBAFgEADIoCEoIgCABQgBAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBg");
	this.shape_32.setTransform(33.5,74.0279);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#00EDF9").s().p("AlAISQgIgFAAgNIgCqBQABgfAbgRIJcleIgBAAQAMgGAIAEQAJAFAAANIABKBQgBAfgbARIpbFeQgHAEgGAAQgEAAgDgCgAj9ABQgFACAAAGIABGVQABAFAEgDIAAABIICkpQAEgDAAgFQAAgGgEADIn9EmIgBmQQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBAAIgBgBIgCABgAjRDFIAACLIA7ghIAAhWIgMAGIALgGIAAg1gAhiB6IAACWIA7giIAAiWgAAMBPIAACBIA7giIAAiBgAB7g6IAADKIA6giIAAjKgAhiAdIAABdIA6giIAAhcgAAMAAIAABPIA6giIAAhPgAj9hNIAAAZIA3ggIAAgZgAB7i4IAAB+IA6giIAAh+gAj9iCIAAAZIAAAAIA4ggIAAgZgAgDjbIiVBWQgIAFgBALQAAAEADACQADACADgDIABAAICUhWQAHgFABgLQAAgEgCgCIgDAAIgDABgAhPjlIhJAqQgIAFgBALQAAAEADACQADABAEgCIBIgpQAJgGAAgKQAAgFgDgBIgCgBIgEABgAA+kCIgiAUQgJAGgBAKQAAAFADABQADACAEgCIAigUQAIgFABgLQAAgFgDgBIgCgBIgEABgAg1j0QgEACgDAEIgCAFIAAAFQAAADADADQADABAEgCIgBAAQAEgCACgFQADgEAAgFIAAgCIgBgDIgCgBIgCgBIgEACgAA+k3IhVAyQgJAFgBALQABAEACACQADABAEgCIBVgyQAJgFAAgLQAAgEgCgCIgDAAIgEABg");
	this.shape_33.setTransform(33.125,53.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group4796_1, new cjs.Rectangle(0,0,66.3,106.4), null);


(lib.ClipGroup_75 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EjFOBnDMAAAjOFMGKdAAAMAAADOFg");
	mask.setTransform(1262.275,659.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AhoBVIAAipIDRAAIAACpg");
	this.shape.setTransform(10.5,114.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_75, new cjs.Rectangle(0,106,21,17), null);


(lib.ClipGroup_74 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AIJMQIzPrIQgMgHACgOICps0IADgGQAEgIAIgCQAIgCAIAEITPLIQAFADADAGQADAGgBAGIipM0IgDAGQgEAHgIADIgFAAQgGAAgFgCg");
	mask.setTransform(140.2185,152.975);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#064280","#064280","#0D0730","#010333"],[0,0.09,0.624,1],-49.1,-76.4,64.4,100.4).s().p("A15kNIZwzsISDcHI5wTsg");
	this.shape.setTransform(140.225,152.975);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_74, new cjs.Rectangle(68.1,74.4,144.3,157.2), null);


(lib.ClipGroup_72 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlUhUIDChwIHoEZIjDBwg");
	mask.setTransform(59.15,34.125);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#0182AA","#0D0730","#010333"],[0,0.612,1],-38.3,-9.6,66.4,16.7).s().p("ApOCHIFmnbIM3DPIlmHag");
	this.shape.setTransform(59.125,34.125);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_72, new cjs.Rectangle(25,14.4,68.3,39.5), null);


(lib.ClipGroup_70 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgmBA84QxfhDtuoFQl0jblgk4QkjkBk4ljQi2jNlbmsQlJmViri+Qj0kPASlsQARlWD5mWQDtmEGvmeQGkmUIymGQIymGKFlPQKVlXKrj7QXVolTfAAIAHAAQUyACSjDyQThD+OiHpQPmILIYLrQJEMnACP6IAAA4QgIIahOFnQhOFrikDuQieDmkJCYQjxCKmCBmQkuBQoqBgQq2B0meBKQ5REj2qG5Q3eHJyiAAQizAAirgLg");
	mask.setTransform(812.3382,390.6662);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#007EE6","#06D3FE"],[0,1],0,-442.4,0,338.9).s().p("Eh2QBFJMAAAiKRMDshAAAMAAACKRg");
	this.shape.setTransform(756.875,442.475);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_70, new cjs.Rectangle(111,0,1402.8,781.4), null);


(lib.ClipGroup_69 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgW0AiJQtngwqjknQqJkclUnHQlYnNAzoWQAvnxEMjxQB5hsC5hQQCXhBDzhBQCRgmFJhQQE4hODphKQKtjdJJl6QEqjBF3hfQFehYGXAAQKOAALTDeQKfDOJKFdQI/FXFHF8QFWGNgfFGQgqGzjHEJQjIEJmzDDQl+Cqr8DHQkoBOn4B5IvLDoQtNDMsUAAQilAAiigJg");
	mask.setTransform(442.4552,219.42);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#007EE6","#06D3FE","#06D3FE"],[0,1,1],0,-243.3,0,195.5).s().p("EhEwAmBMAAAhMBMCJhAAAMAAABMBg");
	this.shape.setTransform(440.1,243.325);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_69, new cjs.Rectangle(12.9,0,859.1,438.9), null);


(lib.ClipGroup_67 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Eg83AtoQgBgFgigsQgzhAgkgyQiPjJhgjoQk7r2DZu1QDWuhPE11QEum0FUmuQCqjYBuiAIBqBDQCJBTCcBXQHzEVHzDKQK5EbJSBdQLoB0Iei9QPalZPHgnQEugMEJATQCEAKBIAMMgABBOaIg3BgIhlA9g");
	mask.setTransform(470.3452,292);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#007EE6","#06D3FE"],[0,1],0,-292,0,292).s().p("EhHdAtoMAAAhbPMCO6AAAMAAABbPg");
	this.shape.setTransform(457.35,292);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_67, new cjs.Rectangle(26,0,888.7,584), null);


(lib.ClipGroup_66 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AigAAIChhcICgBcIigBdg");
	mask.setTransform(22.35,13);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#89DAF4","#008DD7"],[0,1],2.6,-7.2,-2.5,7.2).s().p("AjfBWIBMjXIFzAtIhNDWg");
	this.shape.setTransform(22.35,12.975);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_66, new cjs.Rectangle(6.3,3.7,32.1,18.6), null);


(lib.ClipGroup_65 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhP3zICfhdMAAAAxEIifBcg");
	mask.setTransform(8,161.65);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],-8,0,8,0).s().p("AhPZQMAAAgygICfAAMAAAAygg");
	this.shape.setTransform(8,161.65);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_65, new cjs.Rectangle(0,0,16,323.3), null);


(lib.ClipGroup_64 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhQX0MAAAgxEIChBdMAAAAxDg");
	mask.setTransform(8.05,161.65);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#102465","#102465"],[0,0.996,1],-8,0,8.1,0).s().p("AhQZQMAAAgygIChAAMAAAAygg");
	this.shape.setTransform(8.05,161.65);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_64, new cjs.Rectangle(0,0,16.1,323.3), null);


(lib.ClipGroup_63 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AigYiMAAAgxDICghdIChBdMAAAAxDIihBdg");
	mask.setTransform(18.15,187.9);

	// Layer_3
	this.instance = new lib.Path();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_63, new cjs.Rectangle(2.1,21.6,32.1,332.59999999999997), null);


(lib.ClipGroup_62 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhrAAIBrg9IBrA9IhrA+g");
	mask.setTransform(15,8.65);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#89DAF4","#008DD7"],[0,1],1.7,-4.8,-1.7,4.9).s().p("AiVA5IAziPID4AeIgzCOg");
	this.shape.setTransform(14.975,8.65);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_62, new cjs.Rectangle(4.3,2.5,21.5,12.4), null);


(lib.ClipGroup_61 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag1v6IBrg/MAAAAg0IhrA+g");
	mask.setTransform(5.35,108.15);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],-5.3,0,5.4,0).s().p("Ag1Q5MAAAghyIBrAAMAAAAhyg");
	this.shape.setTransform(5.35,108.15);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_61, new cjs.Rectangle(0,0,10.7,216.3), null);


(lib.ClipGroup_60 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag1P7MAAAgg0IBrA/MAAAAgzg");
	mask.setTransform(5.375,108.15);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#102465","#102465"],[0,0.996,1],-5.3,0,5.4,0).s().p("Ag1Q5MAAAghyIBrAAMAAAAhyg");
	this.shape.setTransform(5.375,108.15);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_60, new cjs.Rectangle(0,0,10.8,216.3), null);


(lib.ClipGroup_59 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhqQaMAAAgg0IBqg9IBrA9MAAAAg0IhrA/g");
	mask.setTransform(12.15,125.7);

	// Layer_3
	this.instance = new lib.Path_0();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_59, new cjs.Rectangle(1.4,14.5,21.5,222.5), null);


(lib.ClipGroup_58 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AigAAIChhcICgBcIigBdg");
	mask.setTransform(22.35,12.95);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#89DAF4","#008DD7"],[0,1],2.6,-7.2,-2.5,7.2).s().p("AjfBWIBMjXIFzAtIhNDWg");
	this.shape.setTransform(22.375,12.95);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_58, new cjs.Rectangle(6.3,3.7,32.1,18.6), null);


(lib.ClipGroup_57 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhPL9IAA2cICfhdIAAX5g");
	mask.setTransform(8,76.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],-8,0,8,0).s().p("AhPL9IAA35ICfAAIAAX5g");
	this.shape.setTransform(8,76.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_57, new cjs.Rectangle(0,0,16,153), null);


(lib.ClipGroup_56 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhQL9IAA35IChBdIAAWcg");
	mask.setTransform(8.05,76.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#102465","#102465"],[0,0.996,1],-7.8,0,7.9,0).s().p("AhQL9IAA35IChAAIAAX5g");
	this.shape.setTransform(8.05,76.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_56, new cjs.Rectangle(0,0,16.1,153), null);


(lib.ClipGroup_55 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AigMsIAA35IChheICgBeIAAX5g");
	mask.setTransform(17.05,93.15);

	// Layer_3
	this.instance = new lib.Path_1();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_55, new cjs.Rectangle(1,12,32.1,162.3), null);


(lib.ClipGroup_54 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhkAAIBkg5IBlA5IhlA7g");
	mask.setTransform(14.025,8.15);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#89DAF4","#008DD7"],[0,1],1.6,-4.5,-1.6,4.5).s().p("AiLA2IAviHIDoAcIgvCGg");
	this.shape.setTransform(14.025,8.15);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_54, new cjs.Rectangle(4,2.3,20.1,11.7), null);


(lib.ClipGroup_53 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Agxu8IBjg6IAAezIhjA6g");
	mask.setTransform(5.025,101.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],-4.9,0,4.9,0).s().p("AgxP3IAA/tIBjAAIAAftg");
	this.shape.setTransform(5.025,101.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_53, new cjs.Rectangle(0,0,10.1,203), null);


(lib.ClipGroup_52 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgyO9IAA+zIBkA6IAAezg");
	mask.setTransform(5.05,101.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#102465","#102465"],[0,0.996,1],-5,0,5.1,0).s().p("AgyP3IAA/tIBkAAIAAftg");
	this.shape.setTransform(5.05,101.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_52, new cjs.Rectangle(0,0,10.1,203), null);


(lib.ClipGroup_51 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhkPaIAA+zIBkg6IBlA6IAAezIhlA6g");
	mask.setTransform(11.375,117.975);

	// Layer_3
	this.instance = new lib.Path_2();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_51, new cjs.Rectangle(1.3,13.6,20.2,208.8), null);


(lib.ClipGroup_49 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Egg2AAAMAg7gTBMAgyATBMggyATCg");
	mask.setTransform(293,169.7);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#89DAF4","#008DD7"],[0,1],32.7,-92.4,-32.5,91.9).s().p("EgtxARgMAPkgsAMBL/AJBMgPkAsAg");
	this.shape.setTransform(293,169.725);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_49, new cjs.Rectangle(82.7,47.9,420.6,243.6), null);


(lib.ClipGroup_48 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AwYVdIAA33MAgxgTCMAAAAq5g");
	mask.setTransform(104.925,137.325);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],-102.2,0,102.3,0).s().p("AwYVdMAAAgq5MAgxAAAMAAAAq5g");
	this.shape.setTransform(104.925,137.325);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_48, new cjs.Rectangle(0,0,209.9,274.7), null);


(lib.ClipGroup_47 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AwdVdMAAAgq5MAg7ATCIAAX3g");
	mask.setTransform(105.375,137.325);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#102465","#102465"],[0,0.996,1],-105.3,0,105.4,0).s().p("AwdVdMAAAgq5MAg7AAAMAAAAq5g");
	this.shape.setTransform(105.375,137.325);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_47, new cjs.Rectangle(0,0,210.8,274.7), null);


(lib.ClipGroup_46 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhEWAtjMAAAhbFMCItAAAMAAABbFg");
	mask.setTransform(437.5,291.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("AhXAAIBXgyIBYAyIhYAzg");
	this.shape.setTransform(534.025,411.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A5FFFF").s().p("AhXAAIBXgyIBYAyIhYAzg");
	this.shape_1.setTransform(717.775,309);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A5FFFF").s().p("AhYAAIBYgyIBZAyIhZAzg");
	this.shape_2.setTransform(353.4,309);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A5FFFF").s().p("AhXAAIBXgyIBYAyIhYAzg");
	this.shape_3.setTransform(534.025,204.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AwdpWIAAgVMAg7ATCIAAAUg");
	this.shape_4.setTransform(428.325,391.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AwYJXMAgxgTCIAAAVMggxATBg");
	this.shape_5.setTransform(638.625,391.3);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_46, new cjs.Rectangle(323,199.8,420.6,253.5), null);


(lib.ClipGroup_45 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmbgTIAAm0IM3HbIAAG0g");
	mask.setTransform(80.925,89.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],13.3,-19.2,-18.4,26.8).s().p("AsoB6IK7v4IOWMFIq7P4g");
	this.shape.setTransform(80.925,89.525);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_45, new cjs.Rectangle(39.7,43.9,82.5,91.19999999999999), null);


(lib.ClipGroup_44 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai7jXIACgBIF1DYIl3DZg");
	mask.setTransform(24.3,28.025);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#144188","#1A7CDE","#1A7CDE"],[0,0.153,0.996,1],19.4,-3.2,-52.6,9).s().p("AjyjPIGnhIIA+HnImnBIg");
	this.shape.setTransform(24.3,28);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_44, new cjs.Rectangle(5.5,6.3,37.7,43.5), null);


(lib.ClipGroup_43 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmbgUIAAmzIM3HcIAAGzg");
	mask.setTransform(80.925,89.55);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],13.3,-19.2,-18.4,26.8).s().p("AsoB6IK7v5IOWMGIq7P4g");
	this.shape.setTransform(80.925,89.55);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_43, new cjs.Rectangle(39.7,44,82.5,91.19999999999999), null);


(lib.ClipGroup_42 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai7jXIACgBIF1DYIl3DZg");
	mask.setTransform(24.3,27.975);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#144188","#1A7CDE","#1A7CDE"],[0,0.153,0.996,1],19.4,-3.3,-52.6,8.9).s().p("AjyjPIGnhIIA+HnImnBIg");
	this.shape.setTransform(24.3,28);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_42, new cjs.Rectangle(5.5,6.3,37.7,43.400000000000006), null);


(lib.ClipGroup_41 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Aj0CNIAAkZIHpEZg");
	mask.setTransform(36.775,40.225);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],5.7,-8.2,-25.9,37.8).s().p("AlvAmIEvm3IGwFsIkvG3g");
	this.shape.setTransform(36.775,40.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_41, new cjs.Rectangle(12.3,26.1,49,28.299999999999997), null);


(lib.ClipGroup_40 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai7CNIAAkYIABgBIF3DYIhxBBg");
	mask.setTransform(22.35,20.375);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#144188","#1A7CDE","#1A7CDE"],[0,0.153,0.996,1],18.5,-3.1,-53.5,9.1).s().p("AjfiGIGThFIAsFSImUBFg");
	this.shape.setTransform(22.375,20.375);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_40, new cjs.Rectangle(3.5,6.3,37.7,28.2), null);


(lib.ClipGroup_39 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ApIAAIJJlSIJIFSIpIFTg");
	mask.setTransform(81.5,47.175);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#89DAF4","#008DD7"],[0,1],9.4,-26.3,-9.2,26.2).s().p("AsuE4IEVsPIVICgIkVMPg");
	this.shape.setTransform(81.5,47.2);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_39, new cjs.Rectangle(23,13.3,117,67.8), null);


(lib.ClipGroup_38 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkjVCMAAAgkwIJHlTMAAAAqDg");
	mask.setTransform(29.175,134.625);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],-28.4,0,28.5,0).s().p("AkjVCMAAAgqDIJHAAMAAAAqDg");
	this.shape.setTransform(29.175,134.625);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_38, new cjs.Rectangle(0,0,58.4,269.3), null);


(lib.ClipGroup_37 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkkVCMAAAgqDIJJFTMAAAAkwg");
	mask.setTransform(29.325,134.625);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#102465","#102465"],[0,0.996,1],-29.3,0,29.3,0).s().p("AkkVCMAAAgqDIJJAAMAAAAqDg");
	this.shape.setTransform(29.325,134.625);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_37, new cjs.Rectangle(0,0,58.7,269.3), null);


(lib.ClipGroup_36 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhEWAtjMAAAhbFMCItAAAMAAABbFg");
	mask.setTransform(437.5,291.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("AlOAAIFPjBIFODBIlODCg");
	this.shape.setTransform(167,313.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FDF7FB").s().p("AkkihIAAgPIJJFSIAAAPg");
	this.shape_1.setTransform(137.825,337.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDF7FB").s().p("AkjCiIJHlSIAAAPIpHFSg");
	this.shape_2.setTransform(196.325,337.45);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_36, new cjs.Rectangle(108.5,294.6,117,60.5), null);


(lib.ClipGroup_35 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhRNXIAA8MICjBgIAAcKg");
	mask.setTransform(8.25,95.25);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],7.8,0.2,-11.7,-0.2).s().p("AhRO1IAA9tICjADIAAdug");
	this.shape.setTransform(8.225,95.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_35, new cjs.Rectangle(0.1,0.3,16.4,189.89999999999998), null);


(lib.ClipGroup_34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhRAAICjheIAAC9g");
	mask.setTransform(8.45,9.825);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],13.8,0.3,-2.6,0).s().p("AhUBfIADjAICmADIgDDAg");
	this.shape.setTransform(8.475,9.825);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_34, new cjs.Rectangle(0.3,0.4,16.4,18.900000000000002), null);


(lib.ClipGroup_33 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ApIQzMAAAghlIJKEdIJHkdMAAAAhlg");
	mask.setTransform(60.4,113.725);

	// Layer_3
	this.instance = new lib.Path_4();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_33, new cjs.Rectangle(1.9,6.3,117,214.89999999999998), null);


(lib.ClipGroup_32 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ak0AAIE1iyIE0CyIk0Czg");
	mask.setTransform(43.125,24.975);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#89DAF4","#008DD7"],[0,1],4.9,-13.9,-4.9,13.9).s().p("AmuClICTmeILKBVIiSGeg");
	this.shape.setTransform(43.125,24.975);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_32, new cjs.Rectangle(12.2,7.1,61.89999999999999,35.8), null);


(lib.ClipGroup_31 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiZz7IEzizMAAAAqqIkzCzg");
	mask.setTransform(15.425,145.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],-15.4,0,15.5,0).s().p("AiZWvMAAAgtdIEzAAMAAAAtdg");
	this.shape.setTransform(15.425,145.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_31, new cjs.Rectangle(0,0,30.9,291), null);


(lib.ClipGroup_30 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiaT8MAAAgqqIE1CzMAAAAqqg");
	mask.setTransform(15.5,145.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#102465","#102465"],[0,0.996,1],-15.1,0,15.1,0).s().p("AiaWvMAAAgtdIE1AAMAAAAtdg");
	this.shape.setTransform(15.5,145.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_30, new cjs.Rectangle(0,0,31,291), null);


(lib.ClipGroup_29 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhEWAtjMAAAhbFMCItAAAMAAABbFg");
	mask.setTransform(437.5,291.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("AiwAAICwhmICxBmIixBng");
	this.shape.setTransform(787.15,172.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiahVIAAgIIE1CzIAAAHg");
	this.shape_1.setTransform(771.7,185.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AiZBWIEzizIAAAIIkzCyg");
	this.shape_2.setTransform(802.625,185.15);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_29, new cjs.Rectangle(756.2,162.5,61.89999999999998,32), null);


(lib.ClipGroup_28 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ak0ZxMAAAgqpIB6hGIhgqmII1AAIhfKlIB5BHMAAAAqpIk0C0g");
	mask.setTransform(36.375,215.05);

	// Layer_3
	this.instance = new lib.Path_5();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_28, new cjs.Rectangle(5.5,32.2,61.8,365.8), null);


(lib.ClipGroup_27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("An/AAIP/pOIAASdg");
	mask.setTransform(91.3,70.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#89DAF4","#008DD7"],[0,1],23.5,-66.2,-17.1,48.6).s().p("AuQIgIG7zjIVmClIm7Tig");
	this.shape.setTransform(91.3,70.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_27, new cjs.Rectangle(40.2,11.7,102.3,118.2), null);


(lib.ClipGroup_25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("An/ZiMAAAgzDIP/JPMAAAAp0g");
	mask.setTransform(51.15,163.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#102465","#102465"],[0,0.996,1],-51.1,0,76.9,0).s().p("An/ZiMAAAgzDIP/AAMAAAAzDg");
	this.shape.setTransform(51.15,163.4);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_25, new cjs.Rectangle(0,0,102.3,326.8), null);


(lib.ClipGroup_24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhEWAtjMAAAhbFMCItAAAMAAABbFg");
	mask.setTransform(437.5,291.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ap/loIAAgTIT/LjIAAAUg");
	this.shape.setTransform(836.7,306.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF65EB").s().p("Ap8FoIT5rjIAAATIz5Lkg");
	this.shape_1.setTransform(964.425,306.9);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_24, new cjs.Rectangle(772.7,269,102.29999999999995,75.89999999999998), null);


(lib.ClipGroup_23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhRNXIAA8MICjBgIAAcKg");
	mask.setTransform(8.25,95.25);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],8,0.2,-11.9,-0.2).s().p("AhRO1IAA9tICjADIAAdug");
	this.shape.setTransform(8.225,95.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_23, new cjs.Rectangle(0.1,0.3,16.4,189.89999999999998), null);


(lib.ClipGroup_22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhRAAICjheIAAC9g");
	mask.setTransform(8.5,9.825);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],13.8,0.3,-2.6,0).s().p("AhUBfIADjAICmAEIgDC/g");
	this.shape.setTransform(8.475,9.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_22, new cjs.Rectangle(0.3,0.4,16.4,18.900000000000002), null);


(lib.ClipGroup_21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhRNXIAA8MICjBgIAAcKg");
	mask.setTransform(8.25,95.25);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],8,0.2,-11.9,-0.2).s().p("AhRO1IAA9tICjADIAAdug");
	this.shape.setTransform(8.225,95.275);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_21, new cjs.Rectangle(0.1,0.3,16.4,189.89999999999998), null);


(lib.ClipGroup_20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhRAAICjheIAAC9g");
	mask.setTransform(8.5,9.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],13.8,0.3,-2.6,0).s().p("AhUBfIADjAICmADIgDDAg");
	this.shape.setTransform(8.475,9.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_20, new cjs.Rectangle(0.3,0.3,16.4,19), null);


(lib.ClipGroup_19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhEWAtjMAAAhbFMCItAAAMAAABbFg");
	mask.setTransform(437.5,291.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("AorAAIIslBIIrFBIorFCg");
	this.shape.setTransform(900.4,256.025);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19, new cjs.Rectangle(844.9,223.9,30.100000000000023,64.29999999999998), null);


(lib.ClipGroup_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Az8AAIT/rjIT7LjIz7Lkg");
	mask.setTransform(177.95,103.075);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#89DAF4","#008DD7"],[0,1],20.4,-57.5,-20.2,57.3).s().p("A7zKoIJd6uMAuJAFfIpdaug");
	this.shape.setTransform(177.95,103.075);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18, new cjs.Rectangle(50.2,29.1,255.5,148), null);


(lib.ClipGroup_17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ap8JLIAAmyIT5rjIAASVg");
	mask.setTransform(63.725,58.675);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],-62.1,0,62.2,0).s().p("Ap8JLIAAyVIT5AAIAASVg");
	this.shape.setTransform(63.725,58.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17, new cjs.Rectangle(0,0,127.5,117.4), null);


(lib.ClipGroup_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ap/JLIAAyVIT/LjIAAGyg");
	mask.setTransform(64.025,58.675);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#102465","#102465"],[0,0.996,1],-64,0,64,0).s().p("Ap/JLIAAyVIT/AAIAASVg");
	this.shape.setTransform(64.025,58.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16, new cjs.Rectangle(0,0,128.1,117.4), null);


(lib.ClipGroup_15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhEWAtjMAAAhbFMCItAAAMAAABbFg");
	mask.setTransform(437.5,291.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#162A56").s().p("AkSEFIlnjPQgbgQAAgWIAAguQABAWAbAOIFmDPQAgAQAiAAQAiAAAfgQIMInDIAHgEIALgKIAEgGIADgEIAAgDIACgKIAAAyIgBADIAAAAIAAACIgBADIAAAAIAAACIgGAIIAAABIgJAJIgJAGIgBABIsIHDQgfAPgiAAQgjAAgfgPg");
	this.shape.setTransform(715.8,473.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap/lnIAAgTIT/LjIAAATg");
	this.shape_1.setTransform(656.075,516.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ap8FpIT5rjIAAATIz5Ljg");
	this.shape_2.setTransform(783.825,516.35);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_15, new cjs.Rectangle(592.1,446.1,255.5,108.19999999999993), null);


(lib.ClipGroup_14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkSFvIlmjPQgbgQAAgWQgBgWAbgPIMJnDQAfgQAiAAQAjAAAeAQIFnDPQAbAPAAAXQAAAVgbAQIsJHDQgeAQgjAAQgiAAgfgQgACjljIsJHDQgTALAAAPQAAAQATALIFnDPQAWALAYAAQAZAAAWgLIMJnDQATgLAAgPQgBgQgTgLIgggTIgxABIj3iPIACgcIgggSQgWgLgZAAQgYAAgWALg");
	mask.setTransform(102.1246,58.85);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#CDEFFB","#89DAF4"],[0,1],18.9,-38.1,-34.4,70.1).s().p("Av8FHIHFuVIY0EIInFOVg");
	this.shape.setTransform(102.075,59.075);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14, new cjs.Rectangle(36.1,20.6,132.1,76.6), null);


(lib.ClipGroup_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhEWAtjMAAAhbFMCItAAAMAAABbFg");
	mask.setTransform(437.5,291.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#165DA4").s().p("Aj/FkIlmjPQgUgLAAgPQAAgQATgLIMJnDQAWgMAYAAQAZAAAWAMIAhASIgDAcID3CPIAygBIAfATQATAKABARQAAAPgTALIsJHDQgWALgYAAQgZAAgWgLg");
	this.shape.setTransform(715.8,458.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#165DA4").s().p("Aj/FkIlmjPQgUgLAAgPQAAgQATgLIMJnDQAWgMAYAAQAZAAAWAMIAhASIgDAcID3CPIAygBIAfATQATAKABARQAAAPgTALIsJHDQgWALgYAAQgZAAgWgLg");
	this.shape_1.setTransform(715.8,458.35);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13, new cjs.Rectangle(652.4,421.6,126.80000000000007,73.5), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("As2AAIM4ncIM0HcIs0Hcg");
	mask.setTransform(114.6,66.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#89DAF4","#008DD7"],[0,1],12.8,-36.1,-12.7,36).s().p("Ax5G2IGGxNIdtDiImGRNg");
	this.shape.setTransform(114.6,66.375);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(32.4,18.8,164.5,95.3), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmZLIIAAuyIMzndIAAWPg");
	mask.setTransform(41.025,71.175);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],-40,0,40,0).s().p("AmZLIIAA2PIMzAAIAAWPg");
	this.shape.setTransform(41.025,71.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(0,0,82.1,142.4), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmbLIIAA2PIM3HdIAAOyg");
	mask.setTransform(41.225,71.175);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#102465","#102465"],[0,0.996,1],-41.2,0,41.2,0).s().p("AmbLIIAA2PIM3AAIAAWPg");
	this.shape.setTransform(41.225,71.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(0,0,82.5,142.4), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhEWAtjMAAAhbFMCItAAAMAAABbFg");
	mask.setTransform(437.5,291.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDF7FB").s().p("AmbjjIAAgUIM3HcIAAATg");
	this.shape.setTransform(241.775,473.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FDF7FB").s().p("AmZDlIMzncIAAAUIszHbg");
	this.shape_1.setTransform(324.025,473.65);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(200.6,448.9,164.50000000000003,49.60000000000002), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah/AAIB/hJICABJIiABKg");
	mask.setTransform(17.875,10.375);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#89DAF4","#008DD7"],[0,1],2.1,-5.7,-2,5.8).s().p("AiyBEIA9irIEoAkIg9Crg");
	this.shape.setTransform(17.875,10.375);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(5.1,3,25.6,14.8), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag/FsIAAqNIB/hKIAALXg");
	mask.setTransform(6.4,36.425);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],-6.2,0,6.3,0).s().p("Ag/FsIAArXIB/AAIAALXg");
	this.shape.setTransform(6.4,36.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0,0,12.8,72.9), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag/FsIAArXIB/BKIAAKNg");
	mask.setTransform(6.425,36.425);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#102465","#102465"],[0,0.996,1],-6.4,0,6.5,0).s().p("Ag/FsIAArXIB/AAIAALXg");
	this.shape.setTransform(6.425,36.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(0,0,12.9,72.9), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah/GSIAArYIB/hKICABKIAALYg");
	mask.setTransform(13.375,49.75);

	// Layer_3
	this.instance = new lib.Path_6();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0.6,9.6,25.599999999999998,80.30000000000001), null);


(lib.ClipGroup_4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AEoIoIzMrFQgFgCgCgFQgFgHADgJQACgIAHgEIJplnQALgFAKAFITLLFQAGAEACADQAEAHgCAJQgCAIgIAEIppFnQgFACgFAAQgFAAgFgCg");
	mask.setTransform(138.6387,81.425);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#F8F8F8","#497684","#010333"],[0,1,1],-100.5,-14.6,94.9,13.8).s().p("A1qHrIIl0YMAivAFDIolUYg");
	this.shape.setTransform(138.65,81.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_1, new cjs.Rectangle(44.3,26,188.7,110.9), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ap81SIT5rkMAAAA2JIz5Lkg");
	mask.setTransform(63.725,210.3);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#144188","#1A7CDE","#1A7CDE"],[0,0.996,1],-62.1,0,62.2,0).s().p("EgJ8Ag3MAAAhBtIT5AAMAAABBtg");
	this.shape.setTransform(63.725,210.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(0,0,127.5,420.6), null);


(lib.ClipGroup_3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AHFMIICps0QABgHgCgGQgDgGgGgDIzPrHQgIgFgJADIALgFQAFgDAFAAQAGAAAEADITQLHQAFADADAGQADAGgCAHIipM0QgCALgLAEIgJAEQAHgFABgHg");
	mask.setTransform(126.4531,155.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#00518B","#00518B","#0182AA","#0D0730","#010333"],[0,0.078,0.282,0.624,1],-65.4,-64,15.9,15.6).s().p("AzuC0IRd7KIWAVjIxdbKg");
	this.shape.setTransform(126.275,155.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_1, new cjs.Rectangle(62.8,77,127.39999999999999,157.6), null);


(lib.ClipGroup_3_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AEoF1IzMrFQgIgEgCgKIAAAAIAAgZQAAAMAKAFITMLFQAKAFAKgFIJplmQAJgGABgJIAAAWQgBAKgJAEIppFnQgFADgFAAQgFAAgFgDg");
	mask.setTransform(155.075,61.85);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#064280","#064280","#0D0730","#010333","#012060","#012060"],[0,0.09,0.373,0.765,0.973,1],-97.8,-14.2,92.9,13.5).s().p("A4OEhIM9uLMAjgAFLIs9OJg");
	this.shape.setTransform(155.1,61.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_0, new cjs.Rectangle(60.8,24.3,188.60000000000002,75.10000000000001), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Egg2AahMAAAhIDMBBtAAAMAAABIDMggyATDg");
	mask.setTransform(214.35,297.2);

	// Layer_3
	this.instance = new lib.Path_3();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(4.1,5.7,420.59999999999997,583.0999999999999), null);


(lib.ClipGroup_2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AHFMIICps0QABgHgCgGQgDgGgGgDIzPrHQgIgFgJADIALgFQAFgDAFAAQAGAAAEADITQLHQAFADADAGQADAGgCAHIipM0QgCALgLAEIgJAEQAHgFABgHg");
	mask.setTransform(76.8531,94.475);

	// Layer_3
	this.instance = new lib.Path_8();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_1, new cjs.Rectangle(13.2,15.7,127.39999999999999,157.60000000000002), null);


(lib.ClipGroup_2_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AEoF1IzMrFQgIgEgCgKIAAAAIAAgZQAAAMAKAFITMLEQAKAGAKgGIJpllQAJgFABgKIAAAWQgBAKgJAEIppFnQgFADgFAAQgFAAgFgDg");
	mask.setTransform(135.125,53.9);

	// Layer_3
	this.instance = new lib.Path_7();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_0, new cjs.Rectangle(40.8,16.4,188.7,75.1), null);


(lib.ClipGroup_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A9avDQACgQAHgXQAPgtAdgeQAsgsBAgGMA2WAAAQAvChAlDpQBJHTg2FpQhLH7k+DiQmPEar2iwQ1Ok7omDYQivBFhHB0QglA7gBAxg");
	mask.setTransform(188.2935,112.8125);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#007EE6","#06D3FE"],[0,1],0,-128.7,0,97.3).s().p("EgiWAUHMAAAgoNMBEtAAAMAAAAoNg");
	this.shape.setTransform(219.9,128.725);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_1, new cjs.Rectangle(0,0,376.6,225.7), null);


(lib.ClipGroup_1_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AFZGBIgggSQgFgCACgEIADgDIAggSQAIgFAIAFIAgASQAEACgBAEQgBABAAAAQAAABgBAAQAAABgBAAQAAAAAAAAIggASQgEACgEAAQgEAAgEgCgAGeFaIghgSQgEgCABgFQAAAAABgBQAAAAAAgBQABAAAAAAQABgBAAAAIAggSQAIgEAIAEIAgASQAFACgCAFQAAAAgBABQAAAAAAABQgBAAAAAAQAAAAgBABIggASQgEACgEAAQgEAAgDgCgAETFZIgggSQgEgCABgEIADgDIAggTQAIgEAIAEIAgASQAFACgCAFQgBAAAAABQAAAAAAABQgBAAAAAAQgBABAAAAIggASQgEACgEAAQgEAAgEgCgAHlE1IgngXQgBAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAIACgCIAngXQAFgCAEACIAnAXQABAAAAAAQAAABABAAQAAAAAAABQAAABAAAAQAAABgBAAQAAAAAAAAQAAAAAAABQgBAAAAAAIgnAXIgFABIgEgBgAFXEyIgggTQgEgCABgEIADgDIAggSQAIgEAIAEIAgASQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAAAQABABAAAAQAAABgBAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAIggATQgEACgEAAQgEAAgEgCgADNExIgggTIgDgCIAAgEIADgDIAggSQAIgEAIAEIAgASQAAAAAAAAQABABAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAIggATQgEACgEAAQgEAAgEgCgAGfEMIgngWQgBgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBIACgBIAngXQAFgCAEACIAnAXQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABIgCACIgnAWIgFABIgEgBgAImELIhng7QgEgCABgEIADgDIAhgTQAHgEAIAEIBnA8QAEABgBAFQAAAAgBABQAAAAAAABQgBAAAAAAQAAAAgBAAIggATQgEACgEAAQgEAAgEgCgAEREJIgggSQgEgCABgEIADgDIAggTQAIgEAIAEIAgATQAFACgCAEQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBABIggASQgEACgEAAQgEAAgEgCgACHEIIgggSQgEgCABgEQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABAAIAggTQAIgEAIAEIAgATQAEACgBAEQgBAAAAABQAAAAAAABQgBAAAAAAQgBABAAAAIggASQgEACgEAAQgEAAgEgCgAJuDmIgngXQgBAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAAAQABgBAAAAQAAAAABAAIAngXQAEgBAFABIAnAXQAAAAABAAQAAABAAAAQAAAAAAABQAAABAAAAQAAAAAAABQAAAAAAAAQgBAAAAABQAAAAAAAAIgnAXIgFAAIgEAAgAFZDkIgngXQgBAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAIACgCIAngWQAFgDAEADIAnAWQABAAAAABQAAAAABABQAAAAAAAAQAAABAAABIgCABIgnAXIgFABIgEgBgADLDhIgggTQgFgBACgFIADgDIAggSQAIgEAIAEIAgASQAEACgBAEQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAIggATQgEACgEAAQgEAAgEgCgABBDgInCkDQgFgCABgEQAAgBABgBQAAAAAAgBQABAAAAAAQABgBABAAIAfgSQAIgEAIAEIHDEDQAEACgBAEQgBABAAAAQAAABgBABQAAAAgBAAQAAABAAAAIggASQgEACgEAAQgEAAgEgCgAIoC9IgngWQgBgBAAAAQgBAAAAAAQAAgBAAgBQAAAAAAgBIACgBIAngXQAEgCAEACIAoAXQAAAAABAAQAAABAAAAQAAAAAAABQAAAAAAABIgBACIgnAWIgFABIgEgBgAETC8IgngXQgBgBAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAIACgCIAngXQAEgCAFACIAnAXQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABIgCACIgnAXIgFAAIgEAAgAGaC6IgggSQgFgCACgEIADgDIAggTQAIgEAHAEIAhATQAEACgBAEQgBAAAAABQAAAAAAABQgBAAAAAAQgBAAAAABIghASQgEACgDAAQgEAAgEgCgACFC4IgggSIgDgCIAAgEIADgDIAggTQAIgEAIAEIAgATQAEABgBAFQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBABIggASQgEACgEAAQgEAAgEgCgAHiCVIgngXQgBAAgBAAQAAgBAAAAQgBgBAAAAQAAgBABAAIACgCIAngWQAEgDAEADIAoAWQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAABIgBABIgoAXIgEABIgEgBgADNCTIgngXQgBAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBIACgCIAngWQAEgDAFADIAnAWQAAAAABABQAAAAABABQAAAAAAAAQAAABAAABQgBAAAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgnAXIgFABIgEgBgAFUCSIgggTQgFgCACgEIADgDIAggSQAIgEAHAEIAhASQAEACgBAEQgBABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAIghATQgEACgDAAQgEAAgEgCgAA/CQIgggSQgFgCACgFQAAgBABAAQAAgBAAAAQABAAAAgBQABAAAAAAIAggSQAIgEAIAEIAgASQAEACgBAFIgDADIggASQgEACgEAAQgEAAgEgCgAGcBsIgngWQgBgBgBAAQAAAAAAgBQgBAAAAAAQAAgBABAAIACgCIAngXQAEgCAEACIAoAXQAAAAABAAQAAABAAAAQAAAAAAABQAAABAAAAIgBACIgoAWIgEABIgEgBgACHBrIgngXQgBAAAAgBQgBAAAAAAQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAAAAAAAQABgBAAAAQAAAAABAAIAngXQAEgCAFACIAnAXQAAAAABAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQgBAAAAABQAAAAAAAAIgnAXIgFABIgEgBgAEOBqIgggTQgFgBACgFQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAIAggTQAIgEAHAEIAhATQAFABgCAFQgBAAAAABQAAAAAAABQgBAAAAAAQgBAAAAABIghATQgEACgDAAQgEAAgEgCgAgGBoIgggTQgEgBABgFQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBABAAIAggTQAHgEAIAEIAgATQAAAAAAAAQABABAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAIggATQgEACgEAAQgDAAgEgCgAFWBEIgogXQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAAAABgBIABgCIAogWQAEgDAEADIAnAWQABAAAAABQABAAAAABQAAAAAAAAQAAABAAABQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgnAXIgEABIgEgBgABBBCIgngWQgBgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQABAAAAAAQAAAAABAAIAngXQAEgCAEACIAoAXQAAAAABAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAAAQAAABAAAAIgnAWIgFABIgEgBgADIBBIghgTIgCgCIAAgDQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAABAAIAhgTQAIgEAHAEIAhATQAAAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAAAAAIghATQgEACgEAAQgDAAgEgCgAhMA/IgggSQgEgCABgEQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAABAAIAggTQAIgEAIAEIAgATQAEACgBAEQgBAAAAABQAAAAAAABQgBAAAAAAQgBABAAAAIggASQgEACgEAAQgEAAgEgCgAEQAcIgogXQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBABAAIABgCIAogWQAEgBAEABIAnAWQABAAAAABQABAAAAAAQAAABAAAAQAAABAAAAIgCACIgnAXIgEABIgEgBgAgEAaIgngXQgBAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAIACgBIAngWQAEgDADADIAoAWQAAAAABABQAAAAAAAAQAAAAAAAAQAAABAAABIgBABIgnAXIgEABIgEgBgACCAZIghgTQgEgBABgFIADgCIAhgTQAIgEAHAEIAhATQAEABgBAEQgBABAAAAQAAABgBAAQAAABgBAAQAAAAAAAAIghATQgEACgEAAQgDAAgEgCgAiSAXIgggTQgEgBABgEIADgDIAggSQAIgEAIAEIAgASQAEACgBADQgBABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAIggATQgEACgEAAQgEAAgEgCgADKgMIgogWQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAABgBIABgBIAngXQAFgCAEACIAnAXQABAAAAAAQAAAAABABQAAAAAAABQAAAAAAABIgCACIgnAWIgEABIgEgBgAhKgOIAAABIgngXQgBgBAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAIACgCIAngXQAEgCAEACIAoAXQAAAAABAAQAAABAAAAQAAAAAAABQAAABAAAAQAAABAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAIgnAWIgFABIgEgBgAA8gPIghgSQgEgCABgEIADgDIAhgTQAIgEAHAEIAhATQAEABgBAFQgBAAAAABQAAAAAAABQgBAAAAAAQgBABAAAAIghASQgEACgEAAQgDAAgEgCgAjYgQIgggTQgFgCACgEQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABAAIAggTQAIgEAIAEIAgATQAEACgBAEQgBAAAAABQAAABgBAAQAAAAgBAAQAAABAAAAIggATQgEACgEAAQgEAAgEgCgACEg0IgogXQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBABAAIABgCIAngWQAFgCAEACIAnAWQABAAAAABQAAAAABAAQAAABAAAAQAAABAAABIgCABIgnAXIgEABIgEgBgAiQg2IgngXQgBAAgBAAQAAAAAAgBQgBAAAAgBQAAAAABgBIACgBIAngXQAEgDAEADIAoAXQAAAAABAAQAAAAAAAAQAAABAAAAQAAABAAABQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAAAAAIgoAXIgEABIgEgBgAgJg3IghgTQgEgBABgFIADgDIAhgSQAIgEAGAEIAhASQAEACgBAEQgBABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAIghATQgEACgDAAQgDAAgEgCgAkeg5IgggSQgFgCACgEIADgDIAggTQAIgEAIAEIAAAAIAgATQAAAAAAAAQABAAAAAAQABABAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAAAQgBAAAAABIggASQgEACgEAAQgEAAgEgCgAmpg6IgfgSQgFgCABgEQAAgBABgBQAAAAAAAAQABgBAAAAQABgBABAAIAfgSQAIgEAIAEIAgASQAFACgCAFQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBABIggASQgEACgEAAQgEAAgEgCgAA9hdIgngWQgBgBAAAAQAAAAgBgBQAAAAAAAAQAAgBABAAIABgCIAngXQAFgCAEACIAnAXQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAAAAAABQgBAAAAAAIgnAWIgEABIgFgBgAjWheIgogXQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBABAAIABgCIAogXQAEgBAEABIAoAXQAAAAABABQAAAAAAAAQAAABAAAAQAAABAAAAIgBACIgoAXIgEABIgEgBgAhPhfIghgTIgDgCIAAgEIADgDIAhgTQAHgEAIAEIAhATQAEABgCAFIgCADIghATQgEACgEAAQgDAAgEgCgAlkhhIgggTQgFgCACgEIADgDIAggSQAIgEAHAEIABAAIAgASQAAAAAAAAQABABAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAIggATQgEACgEAAQgEAAgEgCgAnvhiIgfgTQgFAAABgGQAAAAAAgBQABAAAAgBQABAAAAAAQABgBABAAIAfgSQAIgEAIAEIAgASQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAAAQABABAAAAQAAABgBAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAIggATQgEACgEAAQgEAAgEgCgAgIiFIgngWQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAAAQAAAAAAAAQABAAAAAAIAngXQAFgCADACIAnAXQABAAAAAAQAAAAABAAQAAABAAAAQAAABAAABIgCACIgnAWIgDABIgFgBgAkciHIgogWQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAABgBIABgBIAogXQAEgCAEACIAoAXQAAAAABAAQAAABAAAAQAAAAAAABQAAAAAAABIgBACIgoAWIgEABIgEgBgAiViIIghgSQgEgCABgEIADgDIAhgTQAHgDAIADIAhATIACACIAAAEQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAABIghASQgEACgEAAQgDAAgEgCgAmsiKIirhjQgEgBABgFQAAgBABAAQAAgBAAAAQABAAAAgBQABAAAAAAIAhgTQAIgEAHAEICrBjQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAAAQABABAAAAQAAABgBAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQAAAAgBAAIggATQgEACgEAAQgEAAgEgCgAo1iLIgggSQgFgCACgEIADgDIAggTQAIgEAIAEIAgATQAEABgBAFQAAAAgBABQAAAAAAABQgBAAAAABQgBAAAAAAIggASQgEACgEAAQgEAAgEgCgAhOitIgngXQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBABAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQABAAAAAAIAngXQAFgBAEABIAnAXQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAIgCACIgnAXIgEABIgFgBgAliivIgogXQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAAAABgBIABgCIAogWQAEgDAEADIAnAWQABAAAAABQABAAAAABQAAAAAAAAQAAABAAABIgCABIgnAXIgEABIgEgBgAjbiwIghgTQgEgCABgEIADgDIAhgSQAHgEAIAEIAgASQAFACgCAEQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAIggATQgEACgEAAQgEAAgDgCgAp7izIgggSQgEgCABgFQAAgBABAAQAAgBAAAAQABAAAAgBQABAAAAAAIAggSQAIgEAIAEIAgASQAEACgBAFQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAABIggASQgEACgEAAQgEAAgEgCgAiUjWIgngWQgBgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBIACgBIAngXQAFgCAEACIAnAXQABAAAAAAQAAABABAAQAAAAAAABQAAABAAAAIgCACIgnAWIgFABIgEgBgAkhjYIghgTQgEgCABgEIADgDIAggTQAIgEAIAEIAgATQAFACgCAEQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBABIggATQgEABgEAAQgEAAgDgBgAmojXIgogXQgBgBAAAAQAAAAgBgBQAAAAAAAAQAAgBABAAIABgCIAogXQAEgCAEACIAnAXQABAAAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAAAAAABQgBAAAAAAIgnAXIgEAAIgEAAgAjaj+IgngXQgBAAAAAAQgBgBAAAAQAAgBAAAAQAAAAAAgBIACgCIAngWQAFgDAEADIAnAWQAAAAABABQAAAAABAAQAAABAAAAQAAABAAABIgCABIgnAXIgFABIgEgBgAlwkGIglgVQgRgJgQAJIgkAUQgQAIgRgIIgPgIQgEgCgBgDQgCgEABgEQACgFAEgBIBUgxQAHgDAJAAQAJAAAIADIBUAxQAEACACADQACAEgBAEQgCAFgFABIgOAJQgJAEgIAAQgIAAgIgEgAkekmIhvg/QgBgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQABAAAAAAQAAAAABAAIAngXQAEgCAFACIBuBAQABAAAAAAQABABAAAAQAAAAAAABQAAABAAAAIgCACIgnAWIgEABIgEgBg");
	mask.setTransform(132.1955,76.2375);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#0182AA","#0D0730","#010333"],[0,0.612,1],-72.5,-32.2,69.1,30.8).s().p("A0pBjISAtdIXTKZIx/Nbg");
	this.shape.setTransform(132.175,76.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_0, new cjs.Rectangle(65.1,37.5,134.3,77.5), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EikIBnDMAAAjOFMFIRAAAMAAADOFg");
	mask.setTransform(1050.5,659.5);

	// Layer_3
	this.instance = new lib.Image();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(0,0,2101,1319), null);


(lib.Tween19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(50,50,50,0)").s().p("A0QcUMAAAg4nMAoiAAAMAAAA4ng");
	this.shape.setTransform(-8.1,-512.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A5FFFF").s().p("AgOAJQAAgGAFgDIATgLQAFgCAAAFQAAAGgFACIgTALIgDABQgBAAAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBg");
	this.shape_1.setTransform(-67.7,60.6026);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A5FFFF").s().p("AgJASQgEgDAAgHQABgPAMgJIAAABQAGgEAEADQAEACAAAHQAAAOgOAJQgCADgDAAIgEgBg");
	this.shape_2.setTransform(-79.225,55.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A5FFFF").s().p("AgbAQQAAgGAFgCIAtgaQAFgCAAAFQAAAGgFACIgtAaIgDABQAAAAgBgBQAAAAAAAAQAAgBgBAAQAAgBAAgBg");
	this.shape_3.setTransform(-51.375,39.3863);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A5FFFF").s().p("AgtAaQAAgFAFgDIBRgvQABAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAAAQAAABAAAAQgBAGgEADIhRAuIgDABQgBAAAAAAQAAAAgBgBQAAAAAAgBQAAgBAAgBg");
	this.shape_4.setTransform(-53.15,44.3645);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A5FFFF").s().p("AgKAGQAAgFAFgCIALgHQABgBAAAAQABAAAAAAQABAAAAAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQgBAGgEACIgLAHIgDABQAAAAgBAAQAAAAgBgBQAAAAAAgBQAAgBAAgBg");
	this.shape_5.setTransform(-60.075,48.3691);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#A5FFFF").s().p("AgOAJQAAgGAEgCIAVgLQAEgDAAAFQAAAFgEADIgVAMIgCAAQAAAAgBAAQAAAAAAgBQgBAAAAgBQAAgBAAAAg");
	this.shape_6.setTransform(-71.8,62.9974);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#A5FFFF").s().p("AhdA3QABgGADgDICyhmQAFgDABAGQgBAFgFADIiyBmIgCABQgBAAAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBg");
	this.shape_7.setTransform(-63.9,54.4889);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#A5FFFF").s().p("Ag2AgQAAgFAFgEIBjg5QABAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQAAAFgFAEIhjA5IgDAAQAAAAgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBg");
	this.shape_8.setTransform(-67.8,52.8391);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#A5FFFF").s().p("AhZA0QAAgGAFgCICphiIAAAAQAFgDAAAGQAAAFgFADIipBiIgDABQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAgBAAgBg");
	this.shape_9.setTransform(-64.325,46.8522);

	this.instance = new lib.Path2306();
	this.instance.setTransform(-64.45,52.85,1,1,0,0,0,19.4,20.9);
	this.instance.alpha = 0.6016;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#A5FFFF").s().p("Aj3EfQgJgFAAgQQACgkAfgUQAHgEAGgBIBGh6QgEgIAAgHQACglAegUQAOgIAKAGQAJAGAAAPQAAALgEAJIBGArQAHgIAHgEQAEgEAGAAIBKifQgGgHAAgLQACgkAfgUQALgIANAGIA4hBIAAgEQACglAfgUIgBAAQANgIAKAGQAKAFAAAQQAAARgKAPQgIAPgOAJQgMAIgMgGIg4BBIAAAEQgCAlgfAUQgFADgFABIhLCeQAHAIgBAKQgBAlgfAUQgNAIgKgGQgJgFAAgQQAAgLADgJIhFgqQgHAHgIAFQgGAEgHAAIhFB6QADAHAAAIQgCAlgeAUQgIAEgHAAQgFAAgEgCg");
	this.shape_10.setTransform(14.9,1632.025);

	this.instance_1 = new lib.Path2304();
	this.instance_1.setTransform(14.9,1632.05,1,1,0,0,0,32.5,41.5);
	this.instance_1.alpha = 0.6016;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#A5FFFF").s().p("Ag1gsIBqg+IAACXIhqA+g");
	this.shape_11.setTransform(0,589.3375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#A5FFFF").s().p("AheA/QgDgCAAgEQABgKAIgGICxhmQAEgCADACQACABAAAFQgBAKgIAFIixBmIgEABIgCAAg");
	this.shape_12.setTransform(-18.825,593.596);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#A5FFFF").s().p("AghAbQgDgCABgEQgBgKAKgFIA1gfQAEgCADABQADACAAAEQgBAKgJAGIg1AeIgEABIgDAAg");
	this.shape_13.setTransform(-33.95,602.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#A5FFFF").s().p("AgrAgQgCgBAAgEQABgLAIgFIBJgqQAEgCADACQACABAAAEQAAALgJAFIhJAqIgEABIgDgBg");
	this.shape_14.setTransform(-32.95,610.575);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#A5FFFF").s().p("AgcAYQgCgCAAgEQAAgKAJgGIArgZQAEgCADACQACABAAAFQAAAJgJAGIgrAZIgEACIgDgBg");
	this.shape_15.setTransform(-12.075,602.9123);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#A5FFFF").s().p("AheA+QgDgBAAgEQAAgLAJgFICxhmQAEgCADACQACABAAAEQgBALgIAFIixBmIgEABIgCgBg");
	this.shape_16.setTransform(-27.8,603.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#A5FFFF").s().p("AghAbQgCgCAAgEQAAgKAJgGIA1geQAEgCADABQACACAAAEQAAAKgJAGIg1AeIgEABIgDAAg");
	this.shape_17.setTransform(-12.625,594.425);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#A5FFFF").s().p("AgwAkQgDgCAAgFQABgKAIgFIBUgwQAEgCADACQADABAAAEQgBAKgJAGIhUAwIgEABIgCAAg");
	this.shape_18.setTransform(-32.475,592.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#A5FFFF").s().p("AgcAYQgCgCAAgEQABgKAIgGIArgYQAEgCADABQACACAAAEQAAAKgJAFIgrAZIgEABIgDAAg");
	this.shape_19.setTransform(2.175,568.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#A5FFFF").s().p("AirBrQgDgCAAgEQABgLAIgFIFLi+QADgCADABQADACAAAEQgBALgIAEIlLC/IgEACIgCgBg");
	this.shape_20.setTransform(-20.15,581.1873);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#A5FFFF").s().p("Ag9ArQgDgBAAgFQABgKAIgFIBvhAQADgCAEACQACABAAAEQgBALgIAFIhvBAIgEABIgCgBg");
	this.shape_21.setTransform(-1.2,565.8373);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#A5FFFF").s().p("AiHBWQgDgBAAgFQAAgKAJgFIEDiWQADgBADABQADACAAAEQAAAKgJAGIkDCUIgEACIgCgBg");
	this.shape_22.setTransform(-23.75,578.85);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#A5FFFF").s().p("AjUCCQgCgCAAgEQABgKAIgGIGbjsQADgCAEABQACACAAAEQgBALgIAEImbDtIgEACIgDgBg");
	this.shape_23.setTransform(-16.2,570.0873);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#A5FFFF").s().p("AjUAKIGoj1IABDiImpD1g");
	this.shape_24.setTransform(-16.05,553.025);

	this.instance_2 = new lib.Path2393_1();
	this.instance_2.setTransform(-15.95,573.3,1,1,0,0,0,29.1,55.5);
	this.instance_2.alpha = 0.6016;

	this.instance_3 = new lib.Group4796_1();
	this.instance_3.setTransform(-50.75,1155.1,1,1,0,0,0,33.1,53.1);
	this.instance_3.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.instance_1},{t:this.shape_10},{t:this.instance},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-137.8,-693.4,259.5,2366.9);


(lib.Symbol12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B4FFFF").s().p("AkWhfQAKgoASgkQAkhHAmAVQAfASAhBUQAhBUAWANQAaAPAUgeQAUgdAMAHQAOAIAPA0QAPA1AQAJQANAIAegZQAfgZAcAQQAmAWAhBWQAQArAJAng");
	this.shape.setTransform(31.975,42.1265);

	this.instance = new lib.Path2325();
	this.instance.setTransform(32,37.5,1,1,0,0,0,32,37.5);
	this.instance.alpha = 0.5586;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol12, new cjs.Rectangle(0,0,64,75), null);


(lib.Symbol11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path2328();
	this.instance.setTransform(15.45,16.6,1,1,0,0,0,4.6,6.1);
	this.instance.alpha = 0.8086;

	this.instance_1 = new lib.Path2327();
	this.instance_1.setTransform(14.6,18.75,1,1,0,0,0,14.6,18.7);
	this.instance_1.alpha = 0.5586;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol11, new cjs.Rectangle(0,0,29.1,37.5), null);


(lib.Symbol10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B4FFFF").s().p("AAAAlQgOgJgIgPQgJgOgBgRQAAgPAKgFQAJgGANAIIAAgBQAeAUADAkQAAAPgKAGQgEACgEAAQgHAAgIgFg");
	this.shape.setTransform(13.775,19.2957);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B4FFFF").s().p("Ai1hAIAAgpIBDgnIBFB3ICJhPIAAAAIBaCbIAABeg");
	this.shape_1.setTransform(18.2,32.975);

	this.instance = new lib.Path2329();
	this.instance.setTransform(18.3,19.1,1,1,0,0,0,18.3,19.1);
	this.instance.alpha = 0.5586;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(0,0,36.5,47.5), null);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// MergedLayer_4
	this.instance = new lib.Tween19("synched",0);
	this.instance.setTransform(11.1,725);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:-1286.7},244).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-126.7,-1980.1,259.5,4378.6);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5FFFF").s().p("Ag1gsIBqg+IAACXIhqA+g");
	this.shape.setTransform(45.05,71.5875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A5FFFF").s().p("AheA/QgDgCAAgEQABgKAIgGICxhmQAEgCADACQACABAAAFQgBAKgIAFIixBmIgEABIgCAAg");
	this.shape_1.setTransform(26.225,75.846);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A5FFFF").s().p("AghAbQgDgCABgEQgBgKAKgFIA1gfQAEgCADABQADACAAAEQgBAKgJAGIg1AeIgEABIgDAAg");
	this.shape_2.setTransform(11.1,84.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A5FFFF").s().p("AgrAgQgCgBAAgEQABgLAIgFIBJgqQAEgCADACQACABAAAEQAAALgJAFIhJAqIgEABIgDgBg");
	this.shape_3.setTransform(12.1,92.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A5FFFF").s().p("AgcAYQgCgCAAgEQAAgKAJgGIArgZQAEgCADACQACABAAAFQAAAJgJAGIgrAZIgEACIgDgBg");
	this.shape_4.setTransform(32.975,85.1623);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A5FFFF").s().p("AheA+QgDgBAAgEQAAgLAJgFICxhmQAEgCADACQACABAAAEQgBALgIAFIixBmIgEABIgCgBg");
	this.shape_5.setTransform(17.25,85.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#A5FFFF").s().p("AghAbQgCgCAAgEQAAgKAJgGIA1geQAEgCADABQACACAAAEQAAAKgJAGIg1AeIgEABIgDAAg");
	this.shape_6.setTransform(32.425,76.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#A5FFFF").s().p("AgwAkQgDgCAAgFQABgKAIgFIBUgwQAEgCADACQADABAAAEQgBAKgJAGIhUAwIgEABIgCAAg");
	this.shape_7.setTransform(12.575,74.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#A5FFFF").s().p("AgcAYQgCgCAAgEQABgKAIgGIArgYQAEgCADABQACACAAAEQAAAKgJAFIgrAZIgEABIgDAAg");
	this.shape_8.setTransform(47.225,50.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#A5FFFF").s().p("AirBrQgDgCAAgEQABgLAIgFIFLi+QADgCADABQADACAAAEQgBALgIAEIlLC/IgEACIgCgBg");
	this.shape_9.setTransform(24.9,63.4373);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#A5FFFF").s().p("Ag9ArQgDgBAAgFQABgKAIgFIBvhAQADgCAEACQACABAAAEQgBALgIAFIhvBAIgEABIgCgBg");
	this.shape_10.setTransform(43.85,48.0873);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#A5FFFF").s().p("AiHBWQgDgBAAgFQAAgKAJgFIEDiWQADgBADABQADACAAAEQAAAKgJAGIkDCUIgEACIgCgBg");
	this.shape_11.setTransform(21.3,61.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#A5FFFF").s().p("AjUCCQgCgCAAgEQABgKAIgGIGbjsQADgCAEABQACACAAAEQgBALgIAEImbDtIgEACIgDgBg");
	this.shape_12.setTransform(28.85,52.3373);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#A5FFFF").s().p("AjUAKIGoj1IABDiImpD1g");
	this.shape_13.setTransform(29,35.275);

	this.instance = new lib.Path2393();
	this.instance.setTransform(29.1,55.55,1,1,0,0,0,29.1,55.5);
	this.instance.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0,58.1,111), null);


(lib.ClipGroup_73 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ArQMSIAA4jIWhAAIAAYjg");
	mask.setTransform(140.225,152.95);

	// Layer_3
	this.instance = new lib.ClipGroup_74();
	this.instance.setTransform(140.2,153,1,1,0,0,0,140.2,153);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_73, new cjs.Rectangle(68.1,74.3,144.3,157.3), null);


(lib.ClipGroup_71 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AuvI1IAAxpIdfAAIAARpg");
	mask.setTransform(155.1,85.15);

	// Layer_3
	this.instance = new lib.ClipGroup_72();
	this.instance.setTransform(133.7,92.6,1,1,0,0,0,59.1,34.1);

	this.instance_1 = new lib.ClipGroup_1_0();
	this.instance_1.setTransform(164.35,76.3,1,1,0,0,0,132.2,76.3);

	this.instance_2 = new lib.ClipGroup_2_0();
	this.instance_2.setTransform(155.45,104.25,1,1,0,0,0,135.5,54);

	this.instance_3 = new lib.ClipGroup_3_0();
	this.instance_3.setTransform(155.1,104.2,1,1,0,0,0,155.1,61.9);

	this.instance_4 = new lib.ClipGroup_4_1();
	this.instance_4.setTransform(155.15,84,1,1,0,0,0,138.7,81.4);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2,this.instance_3,this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_71, new cjs.Rectangle(60.8,28.6,188.7,113.1), null);


(lib.ClipGroup_26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhEWAtjMAAAhbFMCItAAAMAAABbFg");
	mask.setTransform(437.5,291.5);

	// Layer_3
	this.instance = new lib.ClipGroup_4();
	this.instance.setTransform(964.4,466.5,1,1,0,0,0,63.7,210.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_26, new cjs.Rectangle(0,0,0,0), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Egg2AtkMAAAhbGMBBtAAAMAAABbGg");
	mask.setTransform(214.35,297.2);

	// Layer_3
	this.instance = new lib.ClipGroup_3();
	this.instance.setTransform(214.5,297.5,1,1,0,0,0,214.5,297.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(4.1,5.7,420.59999999999997,583.0999999999999), null);


(lib.ClipGroup_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EikIBnDMAAAjOFMFIRAAAMAAADOFg");
	mask.setTransform(1050.5,659.5);

	// Layer_3
	this.instance = new lib.ClipGroup_1();
	this.instance.setTransform(1050.5,659.5,1,1,0,0,0,1050.5,659.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0, new cjs.Rectangle(0,0,2101,1319), null);


(lib.Group_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup_73();
	this.instance.setTransform(140.2,153,1,1,0,0,0,140.2,153);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(0,0,280.5,306), null);


(lib.Group_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup_71();
	this.instance.setTransform(155.1,83,1,1,0,0,0,155.1,83);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(0,0,310.2,166), null);


(lib.Group_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup_2();
	this.instance.setTransform(214.5,297.5,1,1,0,0,0,214.5,297.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_0, new cjs.Rectangle(0,0,429,595), null);


(lib.Group = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup_0();
	this.instance.setTransform(1050.5,659.5,1,1,0,0,0,1050.5,659.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,0,2101,1319), null);


(lib.ClipGroup_68 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EjFOBnDMAAAjOFMGKdAAAMAAADOFg");
	mask.setTransform(1262.275,659.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhyhA4kQhTAAg6g6Qg7g7AAhTMAAAhq3QAAhTA7g7QA6g6BTAAMDlDAAAQBTAAA6A6QA7A7AABTMAAABq3QAABTg7A7Qg6A6hTAAg");
	this.shape.setTransform(1262.75,660);

	this.instance = new lib.Group();
	this.instance.setTransform(1262.5,659.5,1,1,0,0,0,1050.5,659.5);
	this.instance.alpha = 0.1602;
	this.instance.compositeOperation = "multiply";

	var maskedShapeInstanceList = [this.shape,this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_68, new cjs.Rectangle(212,0,2101,1319), null);


(lib.ClipGroup_50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhEWAtjMAAAhbFMCItAAAMAAABbFg");
	mask.setTransform(437.5,291.5);

	// Layer_3
	this.instance = new lib.Group_0();
	this.instance.setTransform(533.4,340.45,1,1,0,0,0,214.5,297.5);
	this.instance.alpha = 0.5586;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_50, new cjs.Rectangle(318.9,43,429,540), null);


(lib.ClipGroup_4_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EjFOBnDMAAAjOFMGKdAAAMAAADOFg");
	mask.setTransform(1262.275,659.5);

	// Layer_3
	this.instance = new lib.Group_2();
	this.instance.setTransform(1709.75,692.25,1,1,0,0,0,140.2,153);
	this.instance.alpha = 0.9414;

	this.instance_1 = new lib.Group_1();
	this.instance_1.setTransform(1668,753.45,1,1,0,0,0,155.1,83);
	this.instance_1.alpha = 0.6797;

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_0, new cjs.Rectangle(1512.9,539.3,337.0999999999999,305.9000000000001), null);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EjFOBnDMAAAjOFMGKdAAAMAAADOFg");
	mask.setTransform(1262.275,659.5);

	// Layer_3
	this.instance = new lib.ClipGroup_75();
	this.instance.setTransform(1262.3,659.5,1,1,0,0,0,1262.3,659.5);

	this.instance_1 = new lib.ClipGroup_1_1();
	this.instance_1.setTransform(729.4,426.65,1,1,0,0,0,219.9,128.7);

	this.instance_2 = new lib.ClipGroup_2_1();
	this.instance_2.setTransform(1719.75,692.2,1,1,0,0,0,77,95);

	this.instance_3 = new lib.ClipGroup_3_1();
	this.instance_3.setTransform(1719.45,691.8,1,1,0,0,0,126.3,155.9);

	this.instance_4 = new lib.ClipGroup_4_0();
	this.instance_4.setTransform(1262.3,659.5,1,1,0,0,0,1262.3,659.5);

	this.instance_5 = new lib.ClipGroup_5();
	this.instance_5.setTransform(1249.8,982.1,1,1,0,0,0,13.5,50);

	this.instance_6 = new lib.ClipGroup_6();
	this.instance_6.setTransform(1243.25,985.55,1,1,0,0,0,6.4,36.4);

	this.instance_7 = new lib.ClipGroup_7();
	this.instance_7.setTransform(1256.1,985.55,1,1,0,0,0,6.4,36.4);

	this.instance_8 = new lib.ClipGroup_8();
	this.instance_8.setTransform(1249.7,949.05,1,1,0,0,0,17.9,10.3);

	this.instance_9 = new lib.ClipGroup_9();
	this.instance_9.setTransform(1578.25,730.5,1,1,0,0,0,437.5,291.5);

	this.instance_10 = new lib.ClipGroup_10();
	this.instance_10.setTransform(1382.5,950.85,1,1,0,0,0,41.2,71.2);

	this.instance_11 = new lib.ClipGroup_11();
	this.instance_11.setTransform(1464.75,950.85,1,1,0,0,0,41,71.2);

	this.instance_12 = new lib.ClipGroup_12();
	this.instance_12.setTransform(1423.55,879.55,1,1,0,0,0,114.6,66.3);

	this.instance_13 = new lib.ClipGroup_13();
	this.instance_13.setTransform(1578.25,730.5,1,1,0,0,0,437.5,291.5);

	this.instance_14 = new lib.ClipGroup_14();
	this.instance_14.setTransform(1856.45,897.6,1,1,0,0,0,102,59.1);

	this.instance_15 = new lib.ClipGroup_15();
	this.instance_15.setTransform(1578.25,730.5,1,1,0,0,0,437.5,291.5);

	this.instance_16 = new lib.ClipGroup_16();
	this.instance_16.setTransform(1796.8,963.25,1,1,0,0,0,64,58.6);

	this.instance_17 = new lib.ClipGroup_17();
	this.instance_17.setTransform(1924.55,963.25,1,1,0,0,0,63.7,58.6);

	this.instance_18 = new lib.ClipGroup_18();
	this.instance_18.setTransform(1860.6,904.6,1,1,0,0,0,178,103);

	this.instance_19 = new lib.ClipGroup_19();
	this.instance_19.setTransform(1618.65,730.5,1,1,0,0,0,477.9,291.5);

	this.instance_20 = new lib.ClipGroup_20();
	this.instance_20.setTransform(1977.6,943.75,1,1,0,0,0,8.4,9.8);

	this.instance_21 = new lib.ClipGroup_21();
	this.instance_21.setTransform(1977.65,858.3,1,1,0,0,0,8.2,95.3);

	this.instance_22 = new lib.ClipGroup_22();
	this.instance_22.setTransform(1949.45,927.65,1,1,0,0,0,8.4,9.8);

	this.instance_23 = new lib.ClipGroup_23();
	this.instance_23.setTransform(1949.5,842.25,1,1,0,0,0,8.2,95.3);

	this.instance_24 = new lib.ClipGroup_24();
	this.instance_24.setTransform(1654.75,730.5,1,1,0,0,0,514,291.5);

	this.instance_25 = new lib.ClipGroup_25();
	this.instance_25.setTransform(1964.55,858.6,1,1,0,0,0,51.1,163.4);

	this.instance_26 = new lib.ClipGroup_26();
	this.instance_26.setTransform(1654.75,777.4,1,1,0,0,0,514,338.4);

	this.instance_27 = new lib.ClipGroup_27();
	this.instance_27.setTransform(1964.6,695.2,1,1,0,0,0,91.3,70.8);

	this.instance_28 = new lib.ClipGroup_28();
	this.instance_28.setTransform(1928,719.8,1,1,0,0,0,36.5,215);

	this.instance_29 = new lib.ClipGroup_29();
	this.instance_29.setTransform(1578.25,730.5,1,1,0,0,0,437.5,291.5);

	this.instance_30 = new lib.ClipGroup_30();
	this.instance_30.setTransform(1912.45,757.25,1,1,0,0,0,15.5,145.5);

	this.instance_31 = new lib.ClipGroup_31();
	this.instance_31.setTransform(1943.35,757.25,1,1,0,0,0,15.4,145.5);

	this.instance_32 = new lib.ClipGroup_32();
	this.instance_32.setTransform(1927.85,611.65,1,1,0,0,0,43.1,24.9);

	this.instance_33 = new lib.ClipGroup_33();
	this.instance_33.setTransform(1307.85,914.8,1,1,0,0,0,60.5,114);

	this.instance_34 = new lib.ClipGroup_34();
	this.instance_34.setTransform(1277.25,979.2,1,1,0,0,0,8.4,9.8);

	this.instance_35 = new lib.ClipGroup_35();
	this.instance_35.setTransform(1277.3,893.8,1,1,0,0,0,8.2,95.3);

	this.instance_36 = new lib.ClipGroup_36();
	this.instance_36.setTransform(1578.25,730.5,1,1,0,0,0,437.5,291.5);

	this.instance_37 = new lib.ClipGroup_37();
	this.instance_37.setTransform(1278.55,887.35,1,1,0,0,0,29.3,134.6);

	this.instance_38 = new lib.ClipGroup_38();
	this.instance_38.setTransform(1337.1,887.35,1,1,0,0,0,29.2,134.6);

	this.instance_39 = new lib.ClipGroup_39();
	this.instance_39.setTransform(1307.75,752.75,1,1,0,0,0,81.5,47.2);

	this.instance_40 = new lib.ClipGroup_40();
	this.instance_40.setTransform(1584.9,1007.95,1,1,0,0,0,22.4,20.4);

	this.instance_41 = new lib.ClipGroup_41();
	this.instance_41.setTransform(1590.5,1007.85,1,1,0,0,0,36.8,40.2);

	this.instance_42 = new lib.ClipGroup_42();
	this.instance_42.setTransform(1584.85,950.7,1,1,0,0,0,24.3,28);

	this.instance_43 = new lib.ClipGroup_43();
	this.instance_43.setTransform(1607.2,974.4,1,1,0,0,0,80.9,89.5);

	this.instance_44 = new lib.ClipGroup_44();
	this.instance_44.setTransform(1584.85,885.8,1,1,0,0,0,24.3,28);

	this.instance_45 = new lib.ClipGroup_45();
	this.instance_45.setTransform(1607.2,909.55,1,1,0,0,0,80.9,89.5);

	this.instance_46 = new lib.ClipGroup_46();
	this.instance_46.setTransform(1578.25,730.5,1,1,0,0,0,437.5,291.5);

	this.instance_47 = new lib.ClipGroup_47();
	this.instance_47.setTransform(1569.1,884.65,1,1,0,0,0,105.4,137.3);

	this.instance_48 = new lib.ClipGroup_48();
	this.instance_48.setTransform(1779.35,884.65,1,1,0,0,0,104.9,137.3);

	this.instance_49 = new lib.ClipGroup_49();
	this.instance_49.setTransform(1674,747.35,1,1,0,0,0,293,169.7);

	this.instance_50 = new lib.ClipGroup_50();
	this.instance_50.setTransform(1578.25,757.9,1,1,0,0,0,437.5,318.9);

	this.instance_51 = new lib.ClipGroup_51();
	this.instance_51.setTransform(1448.9,785.05,1,1,0,0,0,11.5,118);

	this.instance_52 = new lib.ClipGroup_52();
	this.instance_52.setTransform(1443.7,787.95,1,1,0,0,0,5,101.5);

	this.instance_53 = new lib.ClipGroup_53();
	this.instance_53.setTransform(1453.8,787.95,1,1,0,0,0,5,101.5);

	this.instance_54 = new lib.ClipGroup_54();
	this.instance_54.setTransform(1448.75,686.5,1,1,0,0,0,14,8.2);

	this.instance_55 = new lib.ClipGroup_55();
	this.instance_55.setTransform(1215.05,941.2,1,1,0,0,0,17.5,93.5);

	this.instance_56 = new lib.ClipGroup_56();
	this.instance_56.setTransform(1206.65,945.5,1,1,0,0,0,8.1,76.5);

	this.instance_57 = new lib.ClipGroup_57();
	this.instance_57.setTransform(1222.65,945.5,1,1,0,0,0,8,76.5);

	this.instance_58 = new lib.ClipGroup_58();
	this.instance_58.setTransform(1214.65,869.05,1,1,0,0,0,22.4,13);

	this.instance_59 = new lib.ClipGroup_59();
	this.instance_59.setTransform(1390.25,801.75,1,1,0,0,0,12.5,126);

	this.instance_60 = new lib.ClipGroup_60();
	this.instance_60.setTransform(1384.55,804.6,1,1,0,0,0,5.4,108.2);

	this.instance_61 = new lib.ClipGroup_61();
	this.instance_61.setTransform(1395.3,804.6,1,1,0,0,0,5.4,108.2);

	this.instance_62 = new lib.ClipGroup_62();
	this.instance_62.setTransform(1389.9,696.45,1,1,0,0,0,15,8.7);

	this.instance_63 = new lib.ClipGroup_63();
	this.instance_63.setTransform(1411.1,789.4,1,1,0,0,0,18.5,188);

	this.instance_64 = new lib.ClipGroup_64();
	this.instance_64.setTransform(1402.8,794,1,1,0,0,0,8.1,161.7);

	this.instance_65 = new lib.ClipGroup_65();
	this.instance_65.setTransform(1418.8,794,1,1,0,0,0,8,161.7);

	this.instance_66 = new lib.ClipGroup_66();
	this.instance_66.setTransform(1410.8,632.3,1,1,0,0,0,22.4,13);

	this.instance_67 = new lib.ClipGroup_67();
	this.instance_67.setTransform(1558.45,730,1,1,0,0,0,457.4,292);

	this.instance_68 = new lib.ClipGroup_68();
	this.instance_68.setTransform(1262.3,659.5,1,1,0,0,0,1262.3,659.5);

	this.instance_69 = new lib.ClipGroup_69();
	this.instance_69.setTransform(446.6,349.5,1,1,0,0,0,440.1,243.3);

	this.instance_70 = new lib.ClipGroup_70();
	this.instance_70.setTransform(1767.7,935.7,1,1,0,0,0,756.9,442.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AtgXIMAAAguPIbBAAMAAAAuPg");
	this.shape.setTransform(86.5,372);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2,this.instance_3,this.instance_4,this.instance_5,this.instance_6,this.instance_7,this.instance_8,this.instance_9,this.instance_10,this.instance_11,this.instance_12,this.instance_13,this.instance_14,this.instance_15,this.instance_16,this.instance_17,this.instance_18,this.instance_19,this.instance_20,this.instance_21,this.instance_22,this.instance_23,this.instance_24,this.instance_25,this.instance_26,this.instance_27,this.instance_28,this.instance_29,this.instance_30,this.instance_31,this.instance_32,this.instance_33,this.instance_34,this.instance_35,this.instance_36,this.instance_37,this.instance_38,this.instance_39,this.instance_40,this.instance_41,this.instance_42,this.instance_43,this.instance_44,this.instance_45,this.instance_46,this.instance_47,this.instance_48,this.instance_49,this.instance_50,this.instance_51,this.instance_52,this.instance_53,this.instance_54,this.instance_55,this.instance_56,this.instance_57,this.instance_58,this.instance_59,this.instance_60,this.instance_61,this.instance_62,this.instance_63,this.instance_64,this.instance_65,this.instance_66,this.instance_67,this.instance_68,this.instance_69,this.instance_70,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,2524.6,1319), null);


// stage content:
(lib.Banner = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// graph_6_6_svg
	this.instance = new lib.Path2323();
	this.instance.setTransform(1838.6,584.55,1,1,0,0,0,18.4,17.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(87).to({_off:false},0).wait(1).to({regY:17.1,y:584.45},0).wait(9).to({alpha:0.1867},0).wait(1).to({alpha:0.3733},0).wait(1).to({alpha:0.56},0).wait(1));

	// graph_6_5_svg
	this.instance_1 = new lib.Symbol10();
	this.instance_1.setTransform(1746.1,532.05,1,1,0,0,0,18.3,23.7);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(87).to({_off:false},0).wait(8).to({alpha:0.2},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:1},0).wait(1));

	// graph_6_4_svg
	this.instance_2 = new lib.Path2322();
	this.instance_2.setTransform(1828.65,547.9,1,1,0,0,0,29.8,34.7);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(87).to({_off:false},0).wait(4).to({alpha:0.0622},0).wait(1).to({alpha:0.1244},0).wait(1).to({alpha:0.1867},0).wait(1).to({alpha:0.2489},0).wait(1).to({alpha:0.3111},0).wait(1).to({alpha:0.3733},0).wait(1).to({alpha:0.4356},0).wait(1).to({alpha:0.4978},0).wait(1).to({alpha:0.56},0).wait(1));

	// graph_6_3_svg
	this.instance_3 = new lib.Symbol11();
	this.instance_3.setTransform(1773.35,511.2,1,1,0,0,0,14.6,18.8);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(87).to({_off:false},0).wait(1).to({regY:18.7,y:511.1},0).wait(5).to({alpha:0.1429},0).wait(1).to({alpha:0.2857},0).wait(1).to({alpha:0.4286},0).wait(1).to({alpha:0.5714},0).wait(1).to({alpha:0.7143},0).wait(1).to({alpha:0.8571},0).wait(1).to({alpha:1},0).wait(1));

	// graph_6_2_svg
	this.instance_4 = new lib.Path2324();
	this.instance_4.setTransform(1829.25,514,1,1,0,0,0,5.7,9.8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(87).to({_off:false},0).wait(11).to({alpha:0.28},0).wait(1).to({alpha:0.56},0).wait(1));

	// graph_6_1_svg
	this.instance_5 = new lib.Symbol12();
	this.instance_5.setTransform(1782.4,474.65,1,1,0,0,0,32,37.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(87).to({_off:false},0).wait(6).to({alpha:0.1429},0).wait(1).to({alpha:0.2857},0).wait(1).to({alpha:0.4286},0).wait(1).to({alpha:0.5714},0).wait(1).to({alpha:0.7143},0).wait(1).to({alpha:0.8571},0).wait(1).to({alpha:1},0).wait(1));

	// Layer_30 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_87 = new cjs.Graphics().p("AvLKoIgSy1QAAijAEiqQAJlVAWgiQAMAMBJAeICzBGQBoArDOBIQDfBNBaAVQFkBsGCAwQDBAYB6ACQgRI1ADAxQgWAAgJALIgFALIg0D2I8/Q2g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(87).to({graphics:mask_graphics_87,x:1560.675,y:519.225}).wait(13));

	// Layer_28
	this.instance_6 = new lib.Symbol6();
	this.instance_6.setTransform(1568.6,543.1,1,1,0,0,0,11.1,612.3);
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(87).to({_off:false},0).wait(13));

	// Layer_24
	this.instance_7 = new lib.Symbol4();
	this.instance_7.setTransform(1682.9,601.1,1,1,0,0,0,-4,0.1);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(87).to({_off:false},0).wait(13));

	// app_screen_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#89D1FF").s().p("AiMhNIABgIIEYCjIgBAIg");
	this.shape.setTransform(1686.5,535.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#5796FF").s().p("AhNghIADgVICYBYIgDAVg");
	this.shape_1.setTransform(1673.25,567.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#5796FF").s().p("AhNghIAEgVICXBYIgEAVg");
	this.shape_2.setTransform(1674.175,562.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#5796FF").s().p("AhNghIAEgVICXBYIgEAVg");
	this.shape_3.setTransform(1675.125,557.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#5796FF").s().p("AhNghIADgVICYBYIgDAVg");
	this.shape_4.setTransform(1676.05,552.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#5796FF").s().p("AhOghIAFgVICYBYIgFAVg");
	this.shape_5.setTransform(1677,547.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#5796FF").s().p("AhNggIAEgWICXBYIgEAVg");
	this.shape_6.setTransform(1677.925,542.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#54C9FF").s().p("AgcAQIALg6IAtAbIgLA6g");
	this.shape_7.setTransform(1686.3,570.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#54C9FF").s().p("AgcAQIAMg6IAtAbIgMA6g");
	this.shape_8.setTransform(1688.125,561.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#54C9FF").s().p("AgcAQIAMg6IAtAbIgLA6g");
	this.shape_9.setTransform(1689.925,552);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#239BD5").s().p("AhvgoIAJgrIDWB8IgJArg");
	this.shape_10.setTransform(1719.7,590.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#239BD5").s().p("AichCIAIgrIExCwIgIArg");
	this.shape_11.setTransform(1716.475,581.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#239BD5").s().p("AiBgzIAIgqID7CRIgIAqg");
	this.shape_12.setTransform(1720.45,576.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#239BD5").s().p("AichCIAJgrIEwCwIgIArg");
	this.shape_13.setTransform(1719.075,568.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#239BD5").s().p("AhzBWIA1kTICyBnIg2EUg");
	this.shape_14.setTransform(1747.05,597.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#889FFF").s().p("AgtgIIAGggIBVAxIgGAgg");
	this.shape_15.setTransform(1757.525,576.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#01FFFF").ss(0.3).p("ADfCCIm9kC");
	this.shape_16.setTransform(1684.175,594.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#01FFFF").ss(0.3).p("ADfCCIm9kD");
	this.shape_17.setTransform(1683.025,600.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#01FFFF").ss(0.3).p("AjvgpIG9EDIAjixIm+kCg");
	this.shape_18.setTransform(1683.6499,597.7504);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#0182AA").s().p("AhGgjIACgKICLBQIgCAKg");
	this.shape_19.setTransform(1723.45,627.65);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#0182AA").s().p("AhXgsIACgKICtBkIgCAJg");
	this.shape_20.setTransform(1722.275,623.65);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#0182AA").s().p("AgtgUIACgKIBZAzIgCAKg");
	this.shape_21.setTransform(1727.05,623.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#0182AA").s().p("AhIgkIACgKICOBSIgCAKg");
	this.shape_22.setTransform(1725,618.55);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#0182AA").s().p("AhXgsIACgLICtBlIgCAKg");
	this.shape_23.setTransform(1724.025,614.625);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#0182AA").s().p("AgtgUIABgLIBaA0IgBAKg");
	this.shape_24.setTransform(1744.5,639.85);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#0182AA").s().p("AhDghIACgKICFBNIgCAKg");
	this.shape_25.setTransform(1742.875,635.575);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#0182AA").s().p("AhOgnIADgKICaBZIgCAKg");
	this.shape_26.setTransform(1742.45,632);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#0182AA").s().p("Ag/gfIACgKIB9BIIgCAKg");
	this.shape_27.setTransform(1744.525,629.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#0182AA").s().p("AhKglIABgKICVBVIgDAKg");
	this.shape_28.setTransform(1743.9,626.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#529DFA").s().p("AkDgiIApjRIHeEVIgpDRg");
	this.shape_29.setTransform(1683.675,597.75);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#064280").s().p("AjfgMIApjSIGWDsIgoDRg");
	this.shape_30.setTransform(1732.4,625.875);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2069C7").s().p("AijBbIBBlOIEGCZIhBFOg");
	this.shape_31.setTransform(1679.2,557.575);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#54C9FF").s().p("AlTgKIBAlPIJnFkIhAFPg");
	this.shape_32.setTransform(1728.5,586.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#7659FF","#748BFF"],[0,1],83.9,0,-33.9,0).s().p("AnWjyIAKg3IOjIcIgKA2g");
	this.shape_33.setTransform(1717.2,553.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},85).wait(15));

	// graph_4_svg
	this.instance_8 = new lib.Symbol3();
	this.instance_8.setTransform(1864,741.2,1,1,0,0,0,29.1,55.5);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(70).to({_off:false},0).wait(1).to({alpha:0.0667},0).wait(1).to({alpha:0.1333},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.2667},0).wait(1).to({alpha:0.3333},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.4667},0).wait(1).to({alpha:0.5333},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.6667},0).wait(1).to({alpha:0.7333},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.8667},0).wait(1).to({alpha:0.9333},0).wait(1).to({alpha:1},0).wait(15));

	// graph_3_svg
	this.instance_9 = new lib.Group4796();
	this.instance_9.setTransform(1423.6,720.05,1,1,0,0,0,33.1,53.1);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(70).to({_off:false},0).wait(1).to({regY:53.2,y:720.15,alpha:0.0433},0).wait(1).to({alpha:0.0867},0).wait(1).to({alpha:0.13},0).wait(1).to({alpha:0.1733},0).wait(1).to({alpha:0.2167},0).wait(1).to({alpha:0.26},0).wait(1).to({alpha:0.3033},0).wait(1).to({alpha:0.3467},0).wait(1).to({alpha:0.39},0).wait(1).to({alpha:0.4333},0).wait(1).to({alpha:0.4767},0).wait(1).to({alpha:0.52},0).wait(1).to({alpha:0.5633},0).wait(1).to({alpha:0.6067},0).wait(1).to({alpha:0.65},0).wait(15));

	// graph_2_svg
	this.instance_10 = new lib.Symbol2();
	this.instance_10.setTransform(1929.25,505.8,1,1,0,0,0,5.5,3.8);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(70).to({_off:false},0).wait(1).to({scaleX:1.1182,scaleY:1.1182,x:1929.2,y:502.55},0).wait(1).to({scaleX:1.2364,scaleY:1.2364,y:499.3},0).wait(1).to({scaleX:1.3545,scaleY:1.3545,y:496.05},0).wait(1).to({scaleX:1.4727,scaleY:1.4727,y:492.8},0).wait(1).to({scaleX:1.5909,scaleY:1.5909,y:489.55},0).wait(1).to({scaleX:1.7091,scaleY:1.7091,y:486.3},0).wait(1).to({scaleX:1.8273,scaleY:1.8273,y:483.1},0).wait(1).to({scaleX:1.9455,scaleY:1.9455,y:479.85},0).wait(1).to({scaleX:2.0636,scaleY:2.0636,y:476.6},0).wait(1).to({scaleX:2.1818,scaleY:2.1818,y:473.35},0).wait(1).to({scaleX:2.3,scaleY:2.3,y:470.1},0).wait(1).to({scaleX:2.4182,scaleY:2.4182,y:466.85},0).wait(1).to({scaleX:2.5364,scaleY:2.5364,y:463.6},0).wait(1).to({scaleX:2.6545,scaleY:2.6545,y:460.4},0).wait(1).to({scaleX:2.7727,scaleY:2.7727,y:457.15},0).wait(1).to({scaleX:2.8909,scaleY:2.8909,y:453.9},0).wait(14));

	// graph_1_svg
	this.instance_11 = new lib.Symbol1();
	this.instance_11.setTransform(1310.25,645.4,1,1,0,0,0,13.7,9.6);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(70).to({_off:false},0).wait(1).to({regY:9.5,scaleX:1.1102,scaleY:1.1102,x:1310.3,y:638.65},0).wait(1).to({scaleX:1.2204,scaleY:1.2204,x:1310.4,y:632.05},0).wait(1).to({scaleX:1.3306,scaleY:1.3306,x:1310.55,y:625.45},0).wait(1).to({scaleX:1.4408,scaleY:1.4408,x:1310.65,y:618.85},0).wait(1).to({scaleX:1.551,scaleY:1.551,x:1310.75,y:612.2},0).wait(1).to({scaleX:1.6612,scaleY:1.6612,x:1310.85,y:605.6},0).wait(1).to({scaleX:1.7714,scaleY:1.7714,x:1310.95,y:599},0).wait(1).to({scaleX:1.8816,scaleY:1.8816,x:1311.1,y:592.4},0).wait(1).to({scaleX:1.9918,scaleY:1.9918,x:1311.2,y:585.7},0).wait(1).to({scaleX:2.102,scaleY:2.102,x:1311.3,y:579.1},0).wait(1).to({scaleX:2.2122,scaleY:2.2122,x:1311.4,y:572.5},0).wait(1).to({scaleX:2.3224,scaleY:2.3224,x:1311.5,y:565.9},0).wait(1).to({scaleX:2.4326,scaleY:2.4326,x:1311.65,y:559.25},0).wait(1).to({scaleX:2.5429,scaleY:2.5429,x:1311.75,y:552.65},0).wait(1).to({scaleX:2.6531,scaleY:2.6531,x:1311.85,y:546.05},0).wait(1).to({scaleX:2.7633,scaleY:2.7633,x:1311.95,y:539.45},0).wait(14));

	// Layer_15 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_66 = new cjs.Graphics().p("AmLQzMAAAghlIMXAAMAAAAhlg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(66).to({graphics:mask_1_graphics_66,x:1976.35,y:501.175}).wait(34));

	// light_5_svg
	this.instance_12 = new lib.Path2367();
	this.instance_12.setTransform(2041.65,488.9,1,1,0,0,0,88.7,133.2);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(66).to({_off:false},0).wait(1).to({alpha:0.0267},0).wait(1).to({alpha:0.0533},0).wait(1).to({alpha:0.08},0).wait(1).to({alpha:0.1067},0).wait(1).to({alpha:0.1333},0).wait(1).to({alpha:0.16},0).wait(1).to({alpha:0.1867},0).wait(1).to({alpha:0.2133},0).wait(1).to({alpha:0.24},0).wait(1).to({alpha:0.2667},0).wait(1).to({alpha:0.2933},0).wait(1).to({alpha:0.32},0).wait(1).to({alpha:0.3467},0).wait(1).to({alpha:0.3733},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.4267},0).wait(1).to({alpha:0.4533},0).wait(1).to({alpha:0.48},0).wait(1).to({alpha:0.5067},0).wait(1).to({alpha:0.5333},0).wait(1).to({alpha:0.56},0).wait(13));

	// light_4_svg
	this.instance_13 = new lib.Path2392();
	this.instance_13.setTransform(1854.85,735.55,1,1,0,0,0,84.8,93.7);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(66).to({_off:false},0).wait(1).to({alpha:0.04},0).wait(1).to({alpha:0.08},0).wait(1).to({alpha:0.12},0).wait(1).to({alpha:0.16},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.24},0).wait(1).to({alpha:0.28},0).wait(1).to({alpha:0.32},0).wait(1).to({alpha:0.36},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.44},0).wait(1).to({alpha:0.48},0).wait(1).to({alpha:0.52},0).wait(1).to({alpha:0.56},0).wait(20));

	// light_3_svg
	this.instance_14 = new lib.Path2408();
	this.instance_14.setTransform(1423.65,708.15,1,1,0,0,0,82.3,114);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(66).to({_off:false},0).wait(1).to({alpha:0.04},0).wait(1).to({alpha:0.08},0).wait(1).to({alpha:0.12},0).wait(1).to({alpha:0.16},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.24},0).wait(1).to({alpha:0.28},0).wait(1).to({alpha:0.32},0).wait(1).to({alpha:0.36},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.44},0).wait(1).to({alpha:0.48},0).wait(1).to({alpha:0.52},0).wait(1).to({alpha:0.56},0).wait(20));

	// light_2_svg
	this.instance_15 = new lib.Path2351();
	this.instance_15.setTransform(1928,474.4,1,1,0,0,0,28.3,42.5);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(66).to({_off:false},0).wait(1).to({alpha:0.0509},0).wait(1).to({alpha:0.1018},0).wait(1).to({alpha:0.1527},0).wait(1).to({alpha:0.2036},0).wait(1).to({alpha:0.2545},0).wait(1).to({alpha:0.3055},0).wait(1).to({alpha:0.3564},0).wait(1).to({alpha:0.4073},0).wait(1).to({alpha:0.4582},0).wait(1).to({alpha:0.5091},0).wait(1).to({alpha:0.56},0).wait(23));

	// light_1_svg
	this.instance_16 = new lib.Path2337();
	this.instance_16.setTransform(1307,586.5,1,1,0,0,0,53.5,80.4);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(66).to({_off:false},0).wait(1).to({alpha:0.0509},0).wait(1).to({alpha:0.1018},0).wait(1).to({alpha:0.1527},0).wait(1).to({alpha:0.2036},0).wait(1).to({alpha:0.2545},0).wait(1).to({alpha:0.3055},0).wait(1).to({alpha:0.3564},0).wait(1).to({alpha:0.4073},0).wait(1).to({alpha:0.4582},0).wait(1).to({alpha:0.5091},0).wait(1).to({alpha:0.56},0).wait(23));

	// light_0_svg_copy_copy
	this.instance_17 = new lib.Path2256();
	this.instance_17.setTransform(1858,615.95,1,1,0,0,0,16.6,32.2);
	this.instance_17.alpha = 0.3984;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(61).to({_off:false},0).wait(1).to({alpha:0.42},0).wait(1).to({alpha:0.44},0).wait(1).to({alpha:0.46},0).wait(1).to({alpha:0.48},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.52},0).wait(1).to({alpha:0.54},0).wait(1).to({alpha:0.56},0).wait(31));

	// light_0_svg_copy
	this.instance_18 = new lib.Path2256();
	this.instance_18.setTransform(1674.3,717.9,1,1,0,0,0,16.6,32.2);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(61).to({_off:false},0).wait(1).to({alpha:0.07},0).wait(1).to({alpha:0.14},0).wait(1).to({alpha:0.21},0).wait(1).to({alpha:0.28},0).wait(1).to({alpha:0.35},0).wait(1).to({alpha:0.42},0).wait(1).to({alpha:0.49},0).wait(1).to({alpha:0.56},0).wait(31));

	// light_0_svg
	this.instance_19 = new lib.Path2256();
	this.instance_19.setTransform(1493.65,615.95,1,1,0,0,0,16.6,32.2);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(61).to({_off:false},0).wait(1).to({alpha:0.07},0).wait(1).to({alpha:0.14},0).wait(1).to({alpha:0.21},0).wait(1).to({alpha:0.28},0).wait(1).to({alpha:0.35},0).wait(1).to({alpha:0.42},0).wait(1).to({alpha:0.49},0).wait(1).to({alpha:0.56},0).wait(31));

	// Layer_7_copy_copy (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_63 = new cjs.Graphics().p("AksiXIAJgmIJQFVIgJAmg");
	var mask_2_graphics_64 = new cjs.Graphics().p("EB5uAniIAJgmIJRFWIgJAmg");
	var mask_2_graphics_65 = new cjs.Graphics().p("EB5+AnrIAJgmIJQFWIgJAmg");
	var mask_2_graphics_66 = new cjs.Graphics().p("EB6OAn0IAJgmIJQFWIgJAmg");
	var mask_2_graphics_67 = new cjs.Graphics().p("EB6dAn9IAJgmIJRFWIgJAmg");
	var mask_2_graphics_68 = new cjs.Graphics().p("EB6tAoGIAJgmIJQFWIgJAmg");
	var mask_2_graphics_69 = new cjs.Graphics().p("EB68AoPIAJgmIJRFWIgJAmg");
	var mask_2_graphics_70 = new cjs.Graphics().p("EB7MAoYIAJgmIJQFWIgJAmg");
	var mask_2_graphics_71 = new cjs.Graphics().p("EB7bAohIAJgmIJRFWIgJAmg");
	var mask_2_graphics_72 = new cjs.Graphics().p("EB7rAoqIAJgmIJRFWIgJAmg");
	var mask_2_graphics_73 = new cjs.Graphics().p("EB77AozIAJgmIJQFWIgJAmg");
	var mask_2_graphics_74 = new cjs.Graphics().p("EB8KAo8IAJgmIJRFWIgJAmg");
	var mask_2_graphics_75 = new cjs.Graphics().p("EB8aApFIAJgmIJQFWIgJAmg");
	var mask_2_graphics_76 = new cjs.Graphics().p("EB8pApOIAJgmIJRFWIgJAmg");
	var mask_2_graphics_77 = new cjs.Graphics().p("EB85ApXIAJgmIJRFWIgJAmg");
	var mask_2_graphics_78 = new cjs.Graphics().p("EB9JApgIAJgmIJQFWIgJAmg");
	var mask_2_graphics_79 = new cjs.Graphics().p("EB9YAppIAJgmIJRFWIgJAmg");
	var mask_2_graphics_80 = new cjs.Graphics().p("EB9oApyIAJgmIJQFWIgJAmg");
	var mask_2_graphics_81 = new cjs.Graphics().p("EB93Ap7IAJgmIJRFWIgJAmg");
	var mask_2_graphics_82 = new cjs.Graphics().p("EB+HAqEIAJgmIJQFWIgJAmg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(63).to({graphics:mask_2_graphics_63,x:1645.175,y:553.625}).wait(1).to({graphics:mask_2_graphics_64,x:839.1842,y:287.225}).wait(1).to({graphics:mask_2_graphics_65,x:840.7434,y:288.125}).wait(1).to({graphics:mask_2_graphics_66,x:842.3026,y:289.025}).wait(1).to({graphics:mask_2_graphics_67,x:843.8618,y:289.925}).wait(1).to({graphics:mask_2_graphics_68,x:845.4211,y:290.825}).wait(1).to({graphics:mask_2_graphics_69,x:846.9803,y:291.725}).wait(1).to({graphics:mask_2_graphics_70,x:848.5395,y:292.625}).wait(1).to({graphics:mask_2_graphics_71,x:850.0987,y:293.525}).wait(1).to({graphics:mask_2_graphics_72,x:851.6579,y:294.425}).wait(1).to({graphics:mask_2_graphics_73,x:853.2171,y:295.325}).wait(1).to({graphics:mask_2_graphics_74,x:854.7763,y:296.225}).wait(1).to({graphics:mask_2_graphics_75,x:856.3355,y:297.125}).wait(1).to({graphics:mask_2_graphics_76,x:857.8947,y:298.025}).wait(1).to({graphics:mask_2_graphics_77,x:859.4539,y:298.925}).wait(1).to({graphics:mask_2_graphics_78,x:861.0132,y:299.825}).wait(1).to({graphics:mask_2_graphics_79,x:862.5724,y:300.725}).wait(1).to({graphics:mask_2_graphics_80,x:864.1316,y:301.625}).wait(1).to({graphics:mask_2_graphics_81,x:865.6908,y:302.525}).wait(1).to({graphics:mask_2_graphics_82,x:867.25,y:303.425}).wait(18));

	// Layer_7_copy
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AksiXIAJgmIJQFVIgJAmg");
	this.shape_34.setTransform(1704.425,587.825);
	this.shape_34._off = true;

	var maskedShapeInstanceList = [this.shape_34];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(63).to({_off:false},0).to({_off:true},24).wait(13));

	// Layer_7
	this.instance_20 = new lib.Tween11("synched",0);
	this.instance_20.setTransform(1704.4,587.8);
	this.instance_20.alpha = 0.3516;
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(63).to({_off:false},0).to({_off:true},24).wait(13));

	// Mask_Code_4 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_52 = new cjs.Graphics().p("AjmhhIANg6IHAD9IgNA7g");
	var mask_3_graphics_53 = new cjs.Graphics().p("EB6rAnDIANg6IHBD+IgMA7g");
	var mask_3_graphics_54 = new cjs.Graphics().p("EB7BAnQIANg7IHBD/IgMA6g");
	var mask_3_graphics_55 = new cjs.Graphics().p("EB7XAncIAMg6IHCD+IgNA7g");
	var mask_3_graphics_56 = new cjs.Graphics().p("EB7sAnpIANg6IHBD+IgMA7g");
	var mask_3_graphics_57 = new cjs.Graphics().p("EB8CAn2IAMg7IHCD/IgMA6g");
	var mask_3_graphics_58 = new cjs.Graphics().p("EB8YAoCIAMg6IHCD+IgNA7g");
	var mask_3_graphics_59 = new cjs.Graphics().p("EB8tAoPIANg7IHBD/IgMA6g");
	var mask_3_graphics_60 = new cjs.Graphics().p("EB9DAobIAMg6IHCD+IgNA7g");
	var mask_3_graphics_61 = new cjs.Graphics().p("EB9ZAooIAMg7IHCD/IgNA6g");
	var mask_3_graphics_62 = new cjs.Graphics().p("EB9uAo0IANg6IHBD+IgMA7g");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(52).to({graphics:mask_3_graphics_52,x:1635.25,y:532.6}).wait(1).to({graphics:mask_3_graphics_53,x:831.34,y:275.3825}).wait(1).to({graphics:mask_3_graphics_54,x:833.505,y:276.64}).wait(1).to({graphics:mask_3_graphics_55,x:835.67,y:277.8975}).wait(1).to({graphics:mask_3_graphics_56,x:837.835,y:279.155}).wait(1).to({graphics:mask_3_graphics_57,x:840,y:280.4125}).wait(1).to({graphics:mask_3_graphics_58,x:842.165,y:281.67}).wait(1).to({graphics:mask_3_graphics_59,x:844.33,y:282.9275}).wait(1).to({graphics:mask_3_graphics_60,x:846.495,y:284.185}).wait(1).to({graphics:mask_3_graphics_61,x:848.66,y:285.4425}).wait(1).to({graphics:mask_3_graphics_62,x:850.825,y:286.7}).wait(1).to({graphics:null,x:0,y:0}).wait(37));

	// Code_4
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_35.setTransform(1670.2871,552.7845);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgFAMIgCgYIADABIABAPIAAAEIACgDIAGgKIADACIgKARg");
	this.shape_36.setTransform(1668.625,551.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgGAKIAEgUIACABIAAADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBABAAIACAAIACAEIgBADIgDgDIgCAAIgBACIAAACIgCALg");
	this.shape_37.setTransform(1667.05,550.75);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_38.setTransform(1665.4371,549.9845);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgBALQgDgCgBgDQgCgCAAgEIADABIABAEIADADIACABQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAgBIgBgCIgCgDIgEgEIgCgDIAAgDIACgDIABgBIACAAIACABIAEAEIACADIAAAEIgDgCIgBgDIgCgCQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAACIABABIABADIAFADIABADIAAADIgCADIgDABIgBABIgCgCg");
	this.shape_39.setTransform(1663.545,548.9063);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQABAAAAgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_40.setTransform(1660.7688,547.705);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_41.setTransform(1658.875,546.225);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgIQgCACgBAEQAAADABADQAAAAAAABQABAAAAABQAAAAABABQAAAAAAAAQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBgBIgCAAIgBAAg");
	this.shape_42.setTransform(1689.4333,556.55);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgJAOIAGgdIADACIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABAAAAAAIADABIAEADIACAGQAAACgBADQAAADgCACQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgDAAIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAAAIgCAKgAAAgIQgCACgBAEQAAADABADQAAAAAAABQABABAAAAQAAABABAAQAAAAAAABQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQACgCAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBgBIgCAAIgBAAg");
	this.shape_43.setTransform(1687.5333,555.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_44.setTransform(1685.6813,554.4417);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgEAAIAAgEIAJAFIgBADg");
	this.shape_45.setTransform(1684.2,553.35);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AADARIACgOQABAAAAgBQAAgBAAAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAIgDgBIgCACIgBACIgCAMIgDgCIAGgcIACABIgBALQACgBACABIAEADIACADIAAAGIgEANg");
	this.shape_46.setTransform(1682.65,552.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAgBABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_47.setTransform(1680.8863,551.475);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_48.setTransform(1679.0371,550.3845);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgBAOIgCgCIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIADAAIgBAHIADACIAAADIgEgCIgCALIAAACIAAACIABABIABAAIAAADIgCgBg");
	this.shape_49.setTransform(1677.75,549.35);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_50.setTransform(1676.1871,548.7345);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_51.setTransform(1674.875,547.55);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_52.setTransform(1673.4313,547.3417);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_53.setTransform(1671.525,546.075);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgCgFABgEQACgGADgBQADgBACACQAEACACAEQACAEgCAFQAAAEgCACQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAIgBAAIgCgBgAgBgHQgCABgBAEQgBADABADIADAEQABABAAAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQgBgDgCgBIgCgBIgBABg");
	this.shape_54.setTransform(1669.6655,544.9741);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgDAOIADgUIADABIgEAUgAAAgLIABgDIAEABIgBAEg");
	this.shape_55.setTransform(1668.4,543.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgBAPIgCgDIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIAEAAIgCAHIADACIAAACIgDgBIgDALIAAACIAAACIABABIABAAIAAADIgCAAg");
	this.shape_56.setTransform(1667.6,543.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_57.setTransform(1665.9813,543.0417);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgGAKIAFgVIABACIAAAEQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAAAAAIADAAIACADIgBACIgDgCIgCAAIgBABIAAAEIgCALg");
	this.shape_58.setTransform(1664.6,541.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AABAOIABgDQgCACgDgCIgEgDIgCgGIAAgFIADgGQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAIAEAAIACACIACAEIACgLIADACIgGAdgAgDgHQgBABgBAFQgBADABADQAAABAAAAQABABAAAAQAAABABAAQAAABABAAQAAAAABAAQAAABABAAQAAAAAAgBQAAAAABAAQACgCAAgEQABgDgBgCQgBgEgCgBIAAAAIgDAAg");
	this.shape_59.setTransform(1662.1375,540.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAAAAAABQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_60.setTransform(1660.2363,539.575);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgJAOIAGgdIADACIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAADgCACQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBAAIgDAAIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABACQABADABACQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQACgCAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_61.setTransform(1698.2833,554.15);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABADQABACABABQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACAAAAgFQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_62.setTransform(1696.3333,553.05);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_63.setTransform(1694.4813,552.0417);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgEAAIAAgEIAJAFIgBADg");
	this.shape_64.setTransform(1693,551);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AADARIADgOQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAIgDgBIgCACIgBADIgCALIgDgCIAGgcIACACIgBAKQABgCAEACIADADIACADIgBAFIgCAOg");
	this.shape_65.setTransform(1691.45,549.75);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAgBABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_66.setTransform(1689.6863,549.125);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_67.setTransform(1687.8371,548.0345);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AAAAPIgDgDIgBgCIABgFIADgLIgDgBIAAgDIADABIAAgFIADAAIgBAHIADACIgBADIgDgCIgBALIAAACIAAABIAAACIABAAIAAADIgBAAg");
	this.shape_68.setTransform(1686.55,547);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_69.setTransform(1684.9871,546.3845);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_70.setTransform(1683.675,545.2);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_71.setTransform(1682.2313,544.9917);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_72.setTransform(1680.325,543.725);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgCgFABgEQACgGADgBQADgBACACQAEACACAEQACAEgCAFQAAAEgCACQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAIgBAAIgCgBgAgBgHQgCABgBAEQgBADABADIADAEQABABAAAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQgBgDgCgBIgCgBIgBABg");
	this.shape_73.setTransform(1678.4655,542.6241);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgDAOIADgUIADABIgDAUgAAAgLIABgDIAEABIgCAEg");
	this.shape_74.setTransform(1677.2,541.45);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgBAPIgCgDIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIAEAAIgCAHIADACIAAADIgEgCIgCALIAAACIAAABIABACIABAAIAAAEIgCgBg");
	this.shape_75.setTransform(1676.4,541.15);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_76.setTransform(1674.7813,540.6917);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgGAKIAFgUIACABIgBADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBAAAAIACAAIADAEIgCADIgCgDIgCAAIgBACIAAACIgDALg");
	this.shape_77.setTransform(1673.4,539.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AAAAOIAAgOIAAgDIgHANIgDgCIgBgXIADACIAAASIACgEIAGgKIACACIAAANIAAAEIACgDIAGgKIACACIgKARg");
	this.shape_78.setTransform(1670.725,537.875);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_79.setTransform(1668.3371,536.7845);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_80.setTransform(1666.375,535.675);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_81.setTransform(1663.5188,534.405);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_82.setTransform(1661.625,532.925);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgEAOIAEgUIADABIgEAUgAABgLIABgDIACABIgBAEg");
	this.shape_83.setTransform(1702.45,548.55);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_84.setTransform(1701.675,548.1);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAAAAAABQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_85.setTransform(1700.3863,547.825);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgHAMIAMgZIADABIgMAag");
	this.shape_86.setTransform(1699.075,546.6);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgGAKIAEgUIADABIgBADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBAAAAIACAAIADAEIgCADIgCgDIgBAAIgCACIAAACIgDALg");
	this.shape_87.setTransform(1698.05,546.25);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_88.setTransform(1696.3813,545.6417);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_89.setTransform(1695.125,544.3);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AACANIAAgDQgCADgDgCIgDgDIgBgDQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAAgCIADgOIAEACIgDAMIgBADIABADIACACIACAAIACgBIABgEIADgKIADABIgEAVg");
	this.shape_90.setTransform(1693.7875,543.925);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_91.setTransform(1691.7688,543.205);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_92.setTransform(1689.875,541.725);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_93.setTransform(1687.9813,540.7917);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgCATQgEgCgCgDIgFgGIgCgHQgBgEABgFQABgFACgDQADgFAFAAQAEgBAEAEQAFACADAEQADAEABAFQABADgBAEQgBAGgEADQgFACgDgCIgCgCIAAgBIgBgCIgCABIgDgBIgCgDIgCgEIABgEIACgGIAEgDQABAAAAAAQABAAAAAAQAAAAAAAAQABAAABABIACACIABAFIACgEIAEACIgGAMIgBACIgBACIABAAIADAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBABAAIABgFQABgDgBgDQgBgEgCgDQgCgEgEgCQgEgCgDAAQgEABgCADQgCADgCAEQgBAFABAEQABAFAEADIAHAGQADADADAAQAEAAACgCIADACIgEADIgGAAQgDAAgDgDgAAAgIIgCAAIgDADIAAADQgBABAAABQAAAAAAAAQAAAAAAABQAAABABAAQAAABAAAAQAAABAAAAQAAAAABABQAAAAAAAAIACABIACgBIADgCIAAgDIAAgFIgBgDIgCgBIAAABg");
	this.shape_94.setTransform(1685.35,539.1889);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_95.setTransform(1681.5688,537.355);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgEAAIABgEIAIAFIAAADg");
	this.shape_96.setTransform(1680.1,536.05);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgEAOIAFgdIAEACIgFAdg");
	this.shape_97.setTransform(1678.225,534.55);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgEAOIAFgdIAEACIgFAdg");
	this.shape_98.setTransform(1677.475,534.1);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_99.setTransform(1676.0313,533.8917);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgBAOIgCgCIgBgCIABgFIACgLIgCgBIAAgDIADABIAAgFIAEAAIgCAHIADACIAAACIgEgBIgCALIAAACIAAACIABABIABAAIAAADIgCgBg");
	this.shape_100.setTransform(1674.8,532.7);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgBALQgDgCgBgDQgCgCAAgEIADABIABAEIADADIACABQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAgBIgBgCIgCgDIgEgEIgCgDIAAgDIACgDIABgBIACAAIACABIAEAEIACADIAAAEIgDgCIgBgDIgCgCQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAACIABABIABADIAFADIABADIAAADIgCADIgDABIgBABIgCgCg");
	this.shape_101.setTransform(1673.245,532.1063);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_102.setTransform(1671.425,531.075);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgDAOIADgVIADACIgEAVgAAAgLIABgDIAEABIgBAEg");
	this.shape_103.setTransform(1670.2,529.9);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AAHAQIADgOIABgCIgCgCIgBgCQAAAAgBAAQAAgBgBAAQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAABAAAAQgBABAAABIgCALIgCgBIACgNQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAIgDAAIgCABIgBAEIgDAKIgDgBIAFgVIACACIAAADIADgCIADABIACADIABAEQADgDADACQADACABADQABACgBADIgDAPg");
	this.shape_104.setTransform(1667.27,528.725);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABADQABACABABQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACAAAAgFQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_105.setTransform(1664.8333,527.4);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_106.setTransform(1662.975,526.225);

	var maskedShapeInstanceList = [this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98,this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35}]},52).to({state:[]},11).to({state:[]},10).wait(27));

	// Mask_Code_3 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_44 = new cjs.Graphics().p("AjmhhIANg7IHAD+IgNA6g");
	var mask_4_graphics_45 = new cjs.Graphics().p("EB63AmlIANg6IHBD+IgMA7g");
	var mask_4_graphics_46 = new cjs.Graphics().p("EB7TAm1IAMg7IHCD/IgNA6g");
	var mask_4_graphics_47 = new cjs.Graphics().p("EB7vAnFIAMg7IHCD/IgNA6g");
	var mask_4_graphics_48 = new cjs.Graphics().p("EB8KAnUIANg6IHBD+IgMA7g");
	var mask_4_graphics_49 = new cjs.Graphics().p("EB8mAnkIANg6IHBD+IgMA7g");
	var mask_4_graphics_50 = new cjs.Graphics().p("EB9CAn0IAMg7IHCD/IgNA6g");
	var mask_4_graphics_51 = new cjs.Graphics().p("EB9eAoEIAMg7IHCD/IgNA6g");
	var mask_4_graphics_52 = new cjs.Graphics().p("EB96AoTIAMg6IHBD/IgMA6g");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_4_graphics_44,x:1636.35,y:525.9}).wait(1).to({graphics:mask_4_graphics_45,x:832.5031,y:272.3531}).wait(1).to({graphics:mask_4_graphics_46,x:835.2813,y:273.9313}).wait(1).to({graphics:mask_4_graphics_47,x:838.0594,y:275.5094}).wait(1).to({graphics:mask_4_graphics_48,x:840.8375,y:277.0875}).wait(1).to({graphics:mask_4_graphics_49,x:843.6156,y:278.6656}).wait(1).to({graphics:mask_4_graphics_50,x:846.3938,y:280.2438}).wait(1).to({graphics:mask_4_graphics_51,x:849.1719,y:281.8219}).wait(1).to({graphics:mask_4_graphics_52,x:851.95,y:283.4}).wait(11).to({graphics:null,x:0,y:0}).wait(37));

	// Code_3
	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_107.setTransform(1670.2871,552.7845);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgFAMIgCgYIADABIABAPIAAAEIACgDIAGgKIADACIgKARg");
	this.shape_108.setTransform(1668.625,551.5);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgGAKIAEgUIACABIAAADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBABAAIACAAIACAEIgBADIgDgDIgCAAIgBACIAAACIgCALg");
	this.shape_109.setTransform(1667.05,550.75);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_110.setTransform(1665.4371,549.9845);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgBALQgDgCgBgDQgCgCAAgEIADABIABAEIADADIACABQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAgBIgBgCIgCgDIgEgEIgCgDIAAgDIACgDIABgBIACAAIACABIAEAEIACADIAAAEIgDgCIgBgDIgCgCQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAACIABABIABADIAFADIABADIAAADIgCADIgDABIgBABIgCgCg");
	this.shape_111.setTransform(1663.545,548.9063);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQABAAAAgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_112.setTransform(1660.7688,547.705);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_113.setTransform(1658.875,546.225);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgIQgCACgBAEQAAADABADQAAAAAAABQABAAAAABQAAAAABABQAAAAAAAAQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBgBIgCAAIgBAAg");
	this.shape_114.setTransform(1689.4333,556.55);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgJAOIAGgdIADACIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABAAAAAAIADABIAEADIACAGQAAACgBADQAAADgCACQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgDAAIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAAAIgCAKgAAAgIQgCACgBAEQAAADABADQAAAAAAABQABABAAAAQAAABABAAQAAAAAAABQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQACgCAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBgBIgCAAIgBAAg");
	this.shape_115.setTransform(1687.5333,555.45);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_116.setTransform(1685.6813,554.4417);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgEAAIAAgEIAJAFIgBADg");
	this.shape_117.setTransform(1684.2,553.35);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AADARIACgOQABAAAAgBQAAgBAAAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAIgDgBIgCACIgBACIgCAMIgDgCIAGgcIACABIgBALQACgBACABIAEADIACADIAAAGIgEANg");
	this.shape_118.setTransform(1682.65,552.1);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAgBABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_119.setTransform(1680.8863,551.475);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_120.setTransform(1679.0371,550.3845);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgBAOIgCgCIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIADAAIgBAHIADACIAAADIgEgCIgCALIAAACIAAACIABABIABAAIAAADIgCgBg");
	this.shape_121.setTransform(1677.75,549.35);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_122.setTransform(1676.1871,548.7345);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_123.setTransform(1674.875,547.55);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_124.setTransform(1673.4313,547.3417);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_125.setTransform(1671.525,546.075);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgCgFABgEQACgGADgBQADgBACACQAEACACAEQACAEgCAFQAAAEgCACQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAIgBAAIgCgBgAgBgHQgCABgBAEQgBADABADIADAEQABABAAAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQgBgDgCgBIgCgBIgBABg");
	this.shape_126.setTransform(1669.6655,544.9741);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgDAOIADgUIADABIgEAUgAAAgLIABgDIAEABIgBAEg");
	this.shape_127.setTransform(1668.4,543.8);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AgBAPIgCgDIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIAEAAIgCAHIADACIAAACIgDgBIgDALIAAACIAAACIABABIABAAIAAADIgCAAg");
	this.shape_128.setTransform(1667.6,543.5);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_129.setTransform(1665.9813,543.0417);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgGAKIAFgVIABACIAAAEQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAAAAAIADAAIACADIgBACIgDgCIgCAAIgBABIAAAEIgCALg");
	this.shape_130.setTransform(1664.6,541.9);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AABAOIABgDQgCACgDgCIgEgDIgCgGIAAgFIADgGQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAIAEAAIACACIACAEIACgLIADACIgGAdgAgDgHQgBABgBAFQgBADABADQAAABAAAAQABABAAAAQAAABABAAQAAABABAAQAAAAABAAQAAABABAAQAAAAAAgBQAAAAABAAQACgCAAgEQABgDgBgCQgBgEgCgBIAAAAIgDAAg");
	this.shape_131.setTransform(1662.1375,540.5);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAAAAAABQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_132.setTransform(1660.2363,539.575);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgJAOIAGgdIADACIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAADgCACQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBAAIgDAAIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABACQABADABACQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQACgCAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_133.setTransform(1698.2833,554.15);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABADQABACABABQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACAAAAgFQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_134.setTransform(1696.3333,553.05);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_135.setTransform(1694.4813,552.0417);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgEAAIAAgEIAJAFIgBADg");
	this.shape_136.setTransform(1693,551);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AADARIADgOQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAIgDgBIgCACIgBADIgCALIgDgCIAGgcIACACIgBAKQABgCAEACIADADIACADIgBAFIgCAOg");
	this.shape_137.setTransform(1691.45,549.75);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAgBABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_138.setTransform(1689.6863,549.125);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_139.setTransform(1687.8371,548.0345);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AAAAPIgDgDIgBgCIABgFIADgLIgDgBIAAgDIADABIAAgFIADAAIgBAHIADACIgBADIgDgCIgBALIAAACIAAABIAAACIABAAIAAADIgBAAg");
	this.shape_140.setTransform(1686.55,547);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_141.setTransform(1684.9871,546.3845);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_142.setTransform(1683.675,545.2);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_143.setTransform(1682.2313,544.9917);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_144.setTransform(1680.325,543.725);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgCgFABgEQACgGADgBQADgBACACQAEACACAEQACAEgCAFQAAAEgCACQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAIgBAAIgCgBgAgBgHQgCABgBAEQgBADABADIADAEQABABAAAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQgBgDgCgBIgCgBIgBABg");
	this.shape_145.setTransform(1678.4655,542.6241);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AgDAOIADgUIADABIgDAUgAAAgLIABgDIAEABIgCAEg");
	this.shape_146.setTransform(1677.2,541.45);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AgBAPIgCgDIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIAEAAIgCAHIADACIAAADIgEgCIgCALIAAACIAAABIABACIABAAIAAAEIgCgBg");
	this.shape_147.setTransform(1676.4,541.15);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_148.setTransform(1674.7813,540.6917);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AgGAKIAFgUIACABIgBADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBAAAAIACAAIADAEIgCADIgCgDIgCAAIgBACIAAACIgDALg");
	this.shape_149.setTransform(1673.4,539.5);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AAAAOIAAgOIAAgDIgHANIgDgCIgBgXIADACIAAASIACgEIAGgKIACACIAAANIAAAEIACgDIAGgKIACACIgKARg");
	this.shape_150.setTransform(1670.725,537.875);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_151.setTransform(1668.3371,536.7845);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_152.setTransform(1666.375,535.675);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_153.setTransform(1663.5188,534.405);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_154.setTransform(1661.625,532.925);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgEAOIAEgUIADABIgEAUgAABgLIABgDIACABIgBAEg");
	this.shape_155.setTransform(1702.45,548.55);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_156.setTransform(1701.675,548.1);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAAAAAABQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_157.setTransform(1700.3863,547.825);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFFFFF").s().p("AgHAMIAMgZIADABIgMAag");
	this.shape_158.setTransform(1699.075,546.6);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("AgGAKIAEgUIADABIgBADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBAAAAIACAAIADAEIgCADIgCgDIgBAAIgCACIAAACIgDALg");
	this.shape_159.setTransform(1698.05,546.25);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_160.setTransform(1696.3813,545.6417);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_161.setTransform(1695.125,544.3);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFFFFF").s().p("AACANIAAgDQgCADgDgCIgDgDIgBgDQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAAgCIADgOIAEACIgDAMIgBADIABADIACACIACAAIACgBIABgEIADgKIADABIgEAVg");
	this.shape_162.setTransform(1693.7875,543.925);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_163.setTransform(1691.7688,543.205);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_164.setTransform(1689.875,541.725);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_165.setTransform(1687.9813,540.7917);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("AgCATQgEgCgCgDIgFgGIgCgHQgBgEABgFQABgFACgDQADgFAFAAQAEgBAEAEQAFACADAEQADAEABAFQABADgBAEQgBAGgEADQgFACgDgCIgCgCIAAgBIgBgCIgCABIgDgBIgCgDIgCgEIABgEIACgGIAEgDQABAAAAAAQABAAAAAAQAAAAAAAAQABAAABABIACACIABAFIACgEIAEACIgGAMIgBACIgBACIABAAIADAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBABAAIABgFQABgDgBgDQgBgEgCgDQgCgEgEgCQgEgCgDAAQgEABgCADQgCADgCAEQgBAFABAEQABAFAEADIAHAGQADADADAAQAEAAACgCIADACIgEADIgGAAQgDAAgDgDgAAAgIIgCAAIgDADIAAADQgBABAAABQAAAAAAAAQAAAAAAABQAAABABAAQAAABAAAAQAAABAAAAQAAAAABABQAAAAAAAAIACABIACgBIADgCIAAgDIAAgFIgBgDIgCgBIAAABg");
	this.shape_166.setTransform(1685.35,539.1889);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_167.setTransform(1681.5688,537.355);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FFFFFF").s().p("AgEAAIABgEIAIAFIAAADg");
	this.shape_168.setTransform(1680.1,536.05);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFFFFF").s().p("AgEAOIAFgdIAEACIgFAdg");
	this.shape_169.setTransform(1678.225,534.55);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FFFFFF").s().p("AgEAOIAFgdIAEACIgFAdg");
	this.shape_170.setTransform(1677.475,534.1);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_171.setTransform(1676.0313,533.8917);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#FFFFFF").s().p("AgBAOIgCgCIgBgCIABgFIACgLIgCgBIAAgDIADABIAAgFIAEAAIgCAHIADACIAAACIgEgBIgCALIAAACIAAACIABABIABAAIAAADIgCgBg");
	this.shape_172.setTransform(1674.8,532.7);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFFFFF").s().p("AgBALQgDgCgBgDQgCgCAAgEIADABIABAEIADADIACABQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAgBIgBgCIgCgDIgEgEIgCgDIAAgDIACgDIABgBIACAAIACABIAEAEIACADIAAAEIgDgCIgBgDIgCgCQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAACIABABIABADIAFADIABADIAAADIgCADIgDABIgBABIgCgCg");
	this.shape_173.setTransform(1673.245,532.1063);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_174.setTransform(1671.425,531.075);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FFFFFF").s().p("AgDAOIADgVIADACIgEAVgAAAgLIABgDIAEABIgBAEg");
	this.shape_175.setTransform(1670.2,529.9);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FFFFFF").s().p("AAHAQIADgOIABgCIgCgCIgBgCQAAAAgBAAQAAgBgBAAQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAABAAAAQgBABAAABIgCALIgCgBIACgNQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAIgDAAIgCABIgBAEIgDAKIgDgBIAFgVIACACIAAADIADgCIADABIACADIABAEQADgDADACQADACABADQABACgBADIgDAPg");
	this.shape_176.setTransform(1667.27,528.725);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABADQABACABABQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACAAAAgFQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_177.setTransform(1664.8333,527.4);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_178.setTransform(1662.975,526.225);

	var maskedShapeInstanceList = [this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115,this.shape_116,this.shape_117,this.shape_118,this.shape_119,this.shape_120,this.shape_121,this.shape_122,this.shape_123,this.shape_124,this.shape_125,this.shape_126,this.shape_127,this.shape_128,this.shape_129,this.shape_130,this.shape_131,this.shape_132,this.shape_133,this.shape_134,this.shape_135,this.shape_136,this.shape_137,this.shape_138,this.shape_139,this.shape_140,this.shape_141,this.shape_142,this.shape_143,this.shape_144,this.shape_145,this.shape_146,this.shape_147,this.shape_148,this.shape_149,this.shape_150,this.shape_151,this.shape_152,this.shape_153,this.shape_154,this.shape_155,this.shape_156,this.shape_157,this.shape_158,this.shape_159,this.shape_160,this.shape_161,this.shape_162,this.shape_163,this.shape_164,this.shape_165,this.shape_166,this.shape_167,this.shape_168,this.shape_169,this.shape_170,this.shape_171,this.shape_172,this.shape_173,this.shape_174,this.shape_175,this.shape_176,this.shape_177,this.shape_178];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107}]},44).to({state:[]},19).to({state:[]},10).wait(27));

	// Mask_Code_2 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_33 = new cjs.Graphics().p("AjmhhIANg7IHAD+IgNA6g");
	var mask_5_graphics_34 = new cjs.Graphics().p("EB62AmBIANg7IHBD/IgMA6g");
	var mask_5_graphics_35 = new cjs.Graphics().p("EB7LAmMIAMg6IHCD+IgNA7g");
	var mask_5_graphics_36 = new cjs.Graphics().p("EB7fAmXIANg6IHBD+IgMA7g");
	var mask_5_graphics_37 = new cjs.Graphics().p("EB70AmjIAMg7IHCD/IgNA6g");
	var mask_5_graphics_38 = new cjs.Graphics().p("EB8IAmuIAMg6IHCD+IgNA7g");
	var mask_5_graphics_39 = new cjs.Graphics().p("EB8cAm6IANg7IHBD/IgMA6g");
	var mask_5_graphics_40 = new cjs.Graphics().p("EB8xAnFIAMg7IHCD/IgNA6g");
	var mask_5_graphics_41 = new cjs.Graphics().p("EB9FAnQIANg6IHBD+IgMA7g");
	var mask_5_graphics_42 = new cjs.Graphics().p("EB9ZAncIANg7IHBD/IgMA6g");
	var mask_5_graphics_43 = new cjs.Graphics().p("EB9uAnnIAMg6IHCD+IgNA7g");
	var mask_5_graphics_44 = new cjs.Graphics().p("EB+CAnzIANg7IHBD+IgMA7g");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(33).to({graphics:mask_5_graphics_33,x:1637.7,y:519.5}).wait(1).to({graphics:mask_5_graphics_34,x:832.4386,y:268.7136}).wait(1).to({graphics:mask_5_graphics_35,x:834.4773,y:269.8523}).wait(1).to({graphics:mask_5_graphics_36,x:836.5159,y:270.9909}).wait(1).to({graphics:mask_5_graphics_37,x:838.5545,y:272.1295}).wait(1).to({graphics:mask_5_graphics_38,x:840.5932,y:273.2682}).wait(1).to({graphics:mask_5_graphics_39,x:842.6318,y:274.4068}).wait(1).to({graphics:mask_5_graphics_40,x:844.6705,y:275.5455}).wait(1).to({graphics:mask_5_graphics_41,x:846.7091,y:276.6841}).wait(1).to({graphics:mask_5_graphics_42,x:848.7477,y:277.8227}).wait(1).to({graphics:mask_5_graphics_43,x:850.7864,y:278.9614}).wait(1).to({graphics:mask_5_graphics_44,x:852.825,y:280.1}).wait(19).to({graphics:null,x:0,y:0}).wait(37));

	// Code_2
	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_179.setTransform(1670.2871,552.7845);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#FFFFFF").s().p("AgFAMIgCgYIADABIABAPIAAAEIACgDIAGgKIADACIgKARg");
	this.shape_180.setTransform(1668.625,551.5);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#FFFFFF").s().p("AgGAKIAEgUIACABIAAADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBABAAIACAAIACAEIgBADIgDgDIgCAAIgBACIAAACIgCALg");
	this.shape_181.setTransform(1667.05,550.75);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_182.setTransform(1665.4371,549.9845);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#FFFFFF").s().p("AgBALQgDgCgBgDQgCgCAAgEIADABIABAEIADADIACABQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAgBIgBgCIgCgDIgEgEIgCgDIAAgDIACgDIABgBIACAAIACABIAEAEIACADIAAAEIgDgCIgBgDIgCgCQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAACIABABIABADIAFADIABADIAAADIgCADIgDABIgBABIgCgCg");
	this.shape_183.setTransform(1663.545,548.9063);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQABAAAAgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_184.setTransform(1660.7688,547.705);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_185.setTransform(1658.875,546.225);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgIQgCACgBAEQAAADABADQAAAAAAABQABAAAAABQAAAAABABQAAAAAAAAQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBgBIgCAAIgBAAg");
	this.shape_186.setTransform(1689.4333,556.55);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#FFFFFF").s().p("AgJAOIAGgdIADACIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABAAAAAAIADABIAEADIACAGQAAACgBADQAAADgCACQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgDAAIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAAAIgCAKgAAAgIQgCACgBAEQAAADABADQAAAAAAABQABABAAAAQAAABABAAQAAAAAAABQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQACgCAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBgBIgCAAIgBAAg");
	this.shape_187.setTransform(1687.5333,555.45);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_188.setTransform(1685.6813,554.4417);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#FFFFFF").s().p("AgEAAIAAgEIAJAFIgBADg");
	this.shape_189.setTransform(1684.2,553.35);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#FFFFFF").s().p("AADARIACgOQABAAAAgBQAAgBAAAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAIgDgBIgCACIgBACIgCAMIgDgCIAGgcIACABIgBALQACgBACABIAEADIACADIAAAGIgEANg");
	this.shape_190.setTransform(1682.65,552.1);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAgBABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_191.setTransform(1680.8863,551.475);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_192.setTransform(1679.0371,550.3845);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#FFFFFF").s().p("AgBAOIgCgCIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIADAAIgBAHIADACIAAADIgEgCIgCALIAAACIAAACIABABIABAAIAAADIgCgBg");
	this.shape_193.setTransform(1677.75,549.35);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_194.setTransform(1676.1871,548.7345);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_195.setTransform(1674.875,547.55);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_196.setTransform(1673.4313,547.3417);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_197.setTransform(1671.525,546.075);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgCgFABgEQACgGADgBQADgBACACQAEACACAEQACAEgCAFQAAAEgCACQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAIgBAAIgCgBgAgBgHQgCABgBAEQgBADABADIADAEQABABAAAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQgBgDgCgBIgCgBIgBABg");
	this.shape_198.setTransform(1669.6655,544.9741);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#FFFFFF").s().p("AgDAOIADgUIADABIgEAUgAAAgLIABgDIAEABIgBAEg");
	this.shape_199.setTransform(1668.4,543.8);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#FFFFFF").s().p("AgBAPIgCgDIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIAEAAIgCAHIADACIAAACIgDgBIgDALIAAACIAAACIABABIABAAIAAADIgCAAg");
	this.shape_200.setTransform(1667.6,543.5);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_201.setTransform(1665.9813,543.0417);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#FFFFFF").s().p("AgGAKIAFgVIABACIAAAEQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAAAAAIADAAIACADIgBACIgDgCIgCAAIgBABIAAAEIgCALg");
	this.shape_202.setTransform(1664.6,541.9);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#FFFFFF").s().p("AABAOIABgDQgCACgDgCIgEgDIgCgGIAAgFIADgGQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAIAEAAIACACIACAEIACgLIADACIgGAdgAgDgHQgBABgBAFQgBADABADQAAABAAAAQABABAAAAQAAABABAAQAAABABAAQAAAAABAAQAAABABAAQAAAAAAgBQAAAAABAAQACgCAAgEQABgDgBgCQgBgEgCgBIAAAAIgDAAg");
	this.shape_203.setTransform(1662.1375,540.5);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAAAAAABQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_204.setTransform(1660.2363,539.575);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#FFFFFF").s().p("AgJAOIAGgdIADACIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAADgCACQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBAAIgDAAIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABACQABADABACQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQACgCAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_205.setTransform(1698.2833,554.15);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABADQABACABABQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACAAAAgFQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_206.setTransform(1696.3333,553.05);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_207.setTransform(1694.4813,552.0417);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#FFFFFF").s().p("AgEAAIAAgEIAJAFIgBADg");
	this.shape_208.setTransform(1693,551);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#FFFFFF").s().p("AADARIADgOQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAIgDgBIgCACIgBADIgCALIgDgCIAGgcIACACIgBAKQABgCAEACIADADIACADIgBAFIgCAOg");
	this.shape_209.setTransform(1691.45,549.75);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAgBABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_210.setTransform(1689.6863,549.125);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_211.setTransform(1687.8371,548.0345);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#FFFFFF").s().p("AAAAPIgDgDIgBgCIABgFIADgLIgDgBIAAgDIADABIAAgFIADAAIgBAHIADACIgBADIgDgCIgBALIAAACIAAABIAAACIABAAIAAADIgBAAg");
	this.shape_212.setTransform(1686.55,547);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_213.setTransform(1684.9871,546.3845);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_214.setTransform(1683.675,545.2);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_215.setTransform(1682.2313,544.9917);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_216.setTransform(1680.325,543.725);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgCgFABgEQACgGADgBQADgBACACQAEACACAEQACAEgCAFQAAAEgCACQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAIgBAAIgCgBgAgBgHQgCABgBAEQgBADABADIADAEQABABAAAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQgBgDgCgBIgCgBIgBABg");
	this.shape_217.setTransform(1678.4655,542.6241);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#FFFFFF").s().p("AgDAOIADgUIADABIgDAUgAAAgLIABgDIAEABIgCAEg");
	this.shape_218.setTransform(1677.2,541.45);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#FFFFFF").s().p("AgBAPIgCgDIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIAEAAIgCAHIADACIAAADIgEgCIgCALIAAACIAAABIABACIABAAIAAAEIgCgBg");
	this.shape_219.setTransform(1676.4,541.15);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_220.setTransform(1674.7813,540.6917);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#FFFFFF").s().p("AgGAKIAFgUIACABIgBADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBAAAAIACAAIADAEIgCADIgCgDIgCAAIgBACIAAACIgDALg");
	this.shape_221.setTransform(1673.4,539.5);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#FFFFFF").s().p("AAAAOIAAgOIAAgDIgHANIgDgCIgBgXIADACIAAASIACgEIAGgKIACACIAAANIAAAEIACgDIAGgKIACACIgKARg");
	this.shape_222.setTransform(1670.725,537.875);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_223.setTransform(1668.3371,536.7845);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_224.setTransform(1666.375,535.675);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_225.setTransform(1663.5188,534.405);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_226.setTransform(1661.625,532.925);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#FFFFFF").s().p("AgEAOIAEgUIADABIgEAUgAABgLIABgDIACABIgBAEg");
	this.shape_227.setTransform(1702.45,548.55);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_228.setTransform(1701.675,548.1);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAAAAAABQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_229.setTransform(1700.3863,547.825);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#FFFFFF").s().p("AgHAMIAMgZIADABIgMAag");
	this.shape_230.setTransform(1699.075,546.6);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#FFFFFF").s().p("AgGAKIAEgUIADABIgBADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBAAAAIACAAIADAEIgCADIgCgDIgBAAIgCACIAAACIgDALg");
	this.shape_231.setTransform(1698.05,546.25);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_232.setTransform(1696.3813,545.6417);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_233.setTransform(1695.125,544.3);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#FFFFFF").s().p("AACANIAAgDQgCADgDgCIgDgDIgBgDQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAAgCIADgOIAEACIgDAMIgBADIABADIACACIACAAIACgBIABgEIADgKIADABIgEAVg");
	this.shape_234.setTransform(1693.7875,543.925);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_235.setTransform(1691.7688,543.205);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_236.setTransform(1689.875,541.725);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_237.setTransform(1687.9813,540.7917);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#FFFFFF").s().p("AgCATQgEgCgCgDIgFgGIgCgHQgBgEABgFQABgFACgDQADgFAFAAQAEgBAEAEQAFACADAEQADAEABAFQABADgBAEQgBAGgEADQgFACgDgCIgCgCIAAgBIgBgCIgCABIgDgBIgCgDIgCgEIABgEIACgGIAEgDQABAAAAAAQABAAAAAAQAAAAAAAAQABAAABABIACACIABAFIACgEIAEACIgGAMIgBACIgBACIABAAIADAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBABAAIABgFQABgDgBgDQgBgEgCgDQgCgEgEgCQgEgCgDAAQgEABgCADQgCADgCAEQgBAFABAEQABAFAEADIAHAGQADADADAAQAEAAACgCIADACIgEADIgGAAQgDAAgDgDgAAAgIIgCAAIgDADIAAADQgBABAAABQAAAAAAAAQAAAAAAABQAAABABAAQAAABAAAAQAAABAAAAQAAAAABABQAAAAAAAAIACABIACgBIADgCIAAgDIAAgFIgBgDIgCgBIAAABg");
	this.shape_238.setTransform(1685.35,539.1889);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_239.setTransform(1681.5688,537.355);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#FFFFFF").s().p("AgEAAIABgEIAIAFIAAADg");
	this.shape_240.setTransform(1680.1,536.05);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#FFFFFF").s().p("AgEAOIAFgdIAEACIgFAdg");
	this.shape_241.setTransform(1678.225,534.55);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#FFFFFF").s().p("AgEAOIAFgdIAEACIgFAdg");
	this.shape_242.setTransform(1677.475,534.1);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_243.setTransform(1676.0313,533.8917);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#FFFFFF").s().p("AgBAOIgCgCIgBgCIABgFIACgLIgCgBIAAgDIADABIAAgFIAEAAIgCAHIADACIAAACIgEgBIgCALIAAACIAAACIABABIABAAIAAADIgCgBg");
	this.shape_244.setTransform(1674.8,532.7);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#FFFFFF").s().p("AgBALQgDgCgBgDQgCgCAAgEIADABIABAEIADADIACABQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAgBIgBgCIgCgDIgEgEIgCgDIAAgDIACgDIABgBIACAAIACABIAEAEIACADIAAAEIgDgCIgBgDIgCgCQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAACIABABIABADIAFADIABADIAAADIgCADIgDABIgBABIgCgCg");
	this.shape_245.setTransform(1673.245,532.1063);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_246.setTransform(1671.425,531.075);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#FFFFFF").s().p("AgDAOIADgVIADACIgEAVgAAAgLIABgDIAEABIgBAEg");
	this.shape_247.setTransform(1670.2,529.9);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#FFFFFF").s().p("AAHAQIADgOIABgCIgCgCIgBgCQAAAAgBAAQAAgBgBAAQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAABAAAAQgBABAAABIgCALIgCgBIACgNQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAIgDAAIgCABIgBAEIgDAKIgDgBIAFgVIACACIAAADIADgCIADABIACADIABAEQADgDADACQADACABADQABACgBADIgDAPg");
	this.shape_248.setTransform(1667.27,528.725);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABADQABACABABQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACAAAAgFQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_249.setTransform(1664.8333,527.4);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_250.setTransform(1662.975,526.225);

	var maskedShapeInstanceList = [this.shape_179,this.shape_180,this.shape_181,this.shape_182,this.shape_183,this.shape_184,this.shape_185,this.shape_186,this.shape_187,this.shape_188,this.shape_189,this.shape_190,this.shape_191,this.shape_192,this.shape_193,this.shape_194,this.shape_195,this.shape_196,this.shape_197,this.shape_198,this.shape_199,this.shape_200,this.shape_201,this.shape_202,this.shape_203,this.shape_204,this.shape_205,this.shape_206,this.shape_207,this.shape_208,this.shape_209,this.shape_210,this.shape_211,this.shape_212,this.shape_213,this.shape_214,this.shape_215,this.shape_216,this.shape_217,this.shape_218,this.shape_219,this.shape_220,this.shape_221,this.shape_222,this.shape_223,this.shape_224,this.shape_225,this.shape_226,this.shape_227,this.shape_228,this.shape_229,this.shape_230,this.shape_231,this.shape_232,this.shape_233,this.shape_234,this.shape_235,this.shape_236,this.shape_237,this.shape_238,this.shape_239,this.shape_240,this.shape_241,this.shape_242,this.shape_243,this.shape_244,this.shape_245,this.shape_246,this.shape_247,this.shape_248,this.shape_249,this.shape_250];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179}]},33).to({state:[]},30).to({state:[]},10).wait(27));

	// Mask_Code_1 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	var mask_6_graphics_21 = new cjs.Graphics().p("AjmhhIAMg7IHBD+IgMA6g");
	var mask_6_graphics_22 = new cjs.Graphics().p("EB68AleIAMg7IHCD/IgNA6g");
	var mask_6_graphics_23 = new cjs.Graphics().p("EB7PAloIAMg6IHCD+IgNA7g");
	var mask_6_graphics_24 = new cjs.Graphics().p("EB7hAlzIANg6IHBD+IgMA7g");
	var mask_6_graphics_25 = new cjs.Graphics().p("EB70Al+IAMg7IHCD/IgNA6g");
	var mask_6_graphics_26 = new cjs.Graphics().p("EB8GAmIIANg6IHBD+IgMA7g");
	var mask_6_graphics_27 = new cjs.Graphics().p("EB8ZAmTIANg6IHBD+IgMA7g");
	var mask_6_graphics_28 = new cjs.Graphics().p("EB8sAmeIAMg7IHCD/IgNA6g");
	var mask_6_graphics_29 = new cjs.Graphics().p("EB8+AmoIANg6IHBD+IgMA7g");
	var mask_6_graphics_30 = new cjs.Graphics().p("EB9RAmzIANg6IHBD+IgMA7g");
	var mask_6_graphics_31 = new cjs.Graphics().p("EB9kAm+IAMg7IHCD/IgNA6g");
	var mask_6_graphics_32 = new cjs.Graphics().p("EB92AnJIANg7IHBD/IgMA6g");
	var mask_6_graphics_33 = new cjs.Graphics().p("EB+JAnTIAMg6IHCD+IgMA7g");

	this.timeline.addTween(cjs.Tween.get(mask_6).to({graphics:null,x:0,y:0}).wait(21).to({graphics:mask_6_graphics_21,x:1639.15,y:512.65}).wait(1).to({graphics:mask_6_graphics_22,x:832.9896,y:265.2188}).wait(1).to({graphics:mask_6_graphics_23,x:834.8542,y:266.2875}).wait(1).to({graphics:mask_6_graphics_24,x:836.7188,y:267.3563}).wait(1).to({graphics:mask_6_graphics_25,x:838.5833,y:268.425}).wait(1).to({graphics:mask_6_graphics_26,x:840.4479,y:269.4938}).wait(1).to({graphics:mask_6_graphics_27,x:842.3125,y:270.5625}).wait(1).to({graphics:mask_6_graphics_28,x:844.1771,y:271.6313}).wait(1).to({graphics:mask_6_graphics_29,x:846.0417,y:272.7}).wait(1).to({graphics:mask_6_graphics_30,x:847.9063,y:273.7688}).wait(1).to({graphics:mask_6_graphics_31,x:849.7708,y:274.8375}).wait(1).to({graphics:mask_6_graphics_32,x:851.6354,y:275.9063}).wait(1).to({graphics:mask_6_graphics_33,x:853.5,y:276.975}).wait(30).to({graphics:null,x:0,y:0}).wait(37));

	// Code_1
	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_251.setTransform(1670.2871,552.7845);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#FFFFFF").s().p("AgFAMIgCgYIADABIABAPIAAAEIACgDIAGgKIADACIgKARg");
	this.shape_252.setTransform(1668.625,551.5);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#FFFFFF").s().p("AgGAKIAEgUIACABIAAADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBABAAIACAAIACAEIgBADIgDgDIgCAAIgBACIAAACIgCALg");
	this.shape_253.setTransform(1667.05,550.75);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_254.setTransform(1665.4371,549.9845);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#FFFFFF").s().p("AgBALQgDgCgBgDQgCgCAAgEIADABIABAEIADADIACABQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAgBIgBgCIgCgDIgEgEIgCgDIAAgDIACgDIABgBIACAAIACABIAEAEIACADIAAAEIgDgCIgBgDIgCgCQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAACIABABIABADIAFADIABADIAAADIgCADIgDABIgBABIgCgCg");
	this.shape_255.setTransform(1663.545,548.9063);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQABAAAAgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_256.setTransform(1660.7688,547.705);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_257.setTransform(1658.875,546.225);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgIQgCACgBAEQAAADABADQAAAAAAABQABAAAAABQAAAAABABQAAAAAAAAQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBgBIgCAAIgBAAg");
	this.shape_258.setTransform(1689.4333,556.55);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#FFFFFF").s().p("AgJAOIAGgdIADACIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABAAAAAAIADABIAEADIACAGQAAACgBADQAAADgCACQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgDAAIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAAAIgCAKgAAAgIQgCACgBAEQAAADABADQAAAAAAABQABABAAAAQAAABABAAQAAAAAAABQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQACgCAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBgBIgCAAIgBAAg");
	this.shape_259.setTransform(1687.5333,555.45);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_260.setTransform(1685.6813,554.4417);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#FFFFFF").s().p("AgEAAIAAgEIAJAFIgBADg");
	this.shape_261.setTransform(1684.2,553.35);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#FFFFFF").s().p("AADARIACgOQABAAAAgBQAAgBAAAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAIgDgBIgCACIgBACIgCAMIgDgCIAGgcIACABIgBALQACgBACABIAEADIACADIAAAGIgEANg");
	this.shape_262.setTransform(1682.65,552.1);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAgBABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_263.setTransform(1680.8863,551.475);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_264.setTransform(1679.0371,550.3845);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#FFFFFF").s().p("AgBAOIgCgCIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIADAAIgBAHIADACIAAADIgEgCIgCALIAAACIAAACIABABIABAAIAAADIgCgBg");
	this.shape_265.setTransform(1677.75,549.35);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_266.setTransform(1676.1871,548.7345);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_267.setTransform(1674.875,547.55);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_268.setTransform(1673.4313,547.3417);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_269.setTransform(1671.525,546.075);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgCgFABgEQACgGADgBQADgBACACQAEACACAEQACAEgCAFQAAAEgCACQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAIgBAAIgCgBgAgBgHQgCABgBAEQgBADABADIADAEQABABAAAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQgBgDgCgBIgCgBIgBABg");
	this.shape_270.setTransform(1669.6655,544.9741);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#FFFFFF").s().p("AgDAOIADgUIADABIgEAUgAAAgLIABgDIAEABIgBAEg");
	this.shape_271.setTransform(1668.4,543.8);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#FFFFFF").s().p("AgBAPIgCgDIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIAEAAIgCAHIADACIAAACIgDgBIgDALIAAACIAAACIABABIABAAIAAADIgCAAg");
	this.shape_272.setTransform(1667.6,543.5);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_273.setTransform(1665.9813,543.0417);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#FFFFFF").s().p("AgGAKIAFgVIABACIAAAEQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAAAAAIADAAIACADIgBACIgDgCIgCAAIgBABIAAAEIgCALg");
	this.shape_274.setTransform(1664.6,541.9);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#FFFFFF").s().p("AABAOIABgDQgCACgDgCIgEgDIgCgGIAAgFIADgGQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAIAEAAIACACIACAEIACgLIADACIgGAdgAgDgHQgBABgBAFQgBADABADQAAABAAAAQABABAAAAQAAABABAAQAAABABAAQAAAAABAAQAAABABAAQAAAAAAgBQAAAAABAAQACgCAAgEQABgDgBgCQgBgEgCgBIAAAAIgDAAg");
	this.shape_275.setTransform(1662.1375,540.5);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAAAAAABQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_276.setTransform(1660.2363,539.575);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#FFFFFF").s().p("AgJAOIAGgdIADACIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAADgCACQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBAAIgDAAIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABACQABADABACQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQACgCAAgEQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_277.setTransform(1698.2833,554.15);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABADQABACABABQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACAAAAgFQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_278.setTransform(1696.3333,553.05);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_279.setTransform(1694.4813,552.0417);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#FFFFFF").s().p("AgEAAIAAgEIAJAFIgBADg");
	this.shape_280.setTransform(1693,551);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#FFFFFF").s().p("AADARIADgOQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAIgDgBIgCACIgBADIgCALIgDgCIAGgcIACACIgBAKQABgCAEACIADADIACADIgBAFIgCAOg");
	this.shape_281.setTransform(1691.45,549.75);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAgBABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_282.setTransform(1689.6863,549.125);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_283.setTransform(1687.8371,548.0345);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#FFFFFF").s().p("AAAAPIgDgDIgBgCIABgFIADgLIgDgBIAAgDIADABIAAgFIADAAIgBAHIADACIgBADIgDgCIgBALIAAACIAAABIAAACIABAAIAAADIgBAAg");
	this.shape_284.setTransform(1686.55,547);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_285.setTransform(1684.9871,546.3845);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_286.setTransform(1683.675,545.2);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_287.setTransform(1682.2313,544.9917);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_288.setTransform(1680.325,543.725);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgCgFABgEQACgGADgBQADgBACACQAEACACAEQACAEgCAFQAAAEgCACQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAIgBAAIgCgBgAgBgHQgCABgBAEQgBADABADIADAEQABABAAAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBAAgEQABgDgBgDQgBgDgCgBIgCgBIgBABg");
	this.shape_289.setTransform(1678.4655,542.6241);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#FFFFFF").s().p("AgDAOIADgUIADABIgDAUgAAAgLIABgDIAEABIgCAEg");
	this.shape_290.setTransform(1677.2,541.45);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#FFFFFF").s().p("AgBAPIgCgDIgBgCIABgFIACgLIgCgBIABgDIACABIAAgFIAEAAIgCAHIADACIAAADIgEgCIgCALIAAACIAAABIABACIABAAIAAAEIgCgBg");
	this.shape_291.setTransform(1676.4,541.15);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_292.setTransform(1674.7813,540.6917);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#FFFFFF").s().p("AgGAKIAFgUIACABIgBADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBAAAAIACAAIADAEIgCADIgCgDIgCAAIgBACIAAACIgDALg");
	this.shape_293.setTransform(1673.4,539.5);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#FFFFFF").s().p("AAAAOIAAgOIAAgDIgHANIgDgCIgBgXIADACIAAASIACgEIAGgKIACACIAAANIAAAEIACgDIAGgKIACACIgKARg");
	this.shape_294.setTransform(1670.725,537.875);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#FFFFFF").s().p("AgBALQgEgCgCgEQgBgFABgEQABgFADgCQADgBACACQAEACACAEQACAEgCAFIAAABIgMgHQgBACABADQABADADABIABABQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIADACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAIgCAAIgDgBgAgBgHQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAJAFIAAgEQgBgDgCgBIgCgBIgBABg");
	this.shape_295.setTransform(1668.3371,536.7845);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_296.setTransform(1666.375,535.675);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_297.setTransform(1663.5188,534.405);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_298.setTransform(1661.625,532.925);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#FFFFFF").s().p("AgEAOIAEgUIADABIgEAUgAABgLIABgDIACABIgBAEg");
	this.shape_299.setTransform(1702.45,548.55);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_300.setTransform(1701.675,548.1);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#FFFFFF").s().p("AgBALQgDgCgCgEQgCgEABgEIADgGQAAAAAAgBQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAABABQADABABAEQACACgBADIgCAAIgBgFIgDgCQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAgBABQgCABgBAEQAAADABADIADAEQAAAAAAABQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAgBIADADQgBADgCABIgCAAIgDgBg");
	this.shape_301.setTransform(1700.3863,547.825);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#FFFFFF").s().p("AgHAMIAMgZIADABIgMAag");
	this.shape_302.setTransform(1699.075,546.6);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#FFFFFF").s().p("AgGAKIAEgUIADABIgBADQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBAAAAIACAAIADAEIgCADIgCgDIgBAAIgCACIAAACIgDALg");
	this.shape_303.setTransform(1698.05,546.25);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_304.setTransform(1696.3813,545.6417);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#FFFFFF").s().p("AgEAOIAFgcIAEABIgFAcg");
	this.shape_305.setTransform(1695.125,544.3);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#FFFFFF").s().p("AACANIAAgDQgCADgDgCIgDgDIgBgDQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAAgCIADgOIAEACIgDAMIgBADIABADIACACIACAAIACgBIABgEIADgKIADABIgEAVg");
	this.shape_306.setTransform(1693.7875,543.925);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_307.setTransform(1691.7688,543.205);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAABQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_308.setTransform(1689.875,541.725);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_309.setTransform(1687.9813,540.7917);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#FFFFFF").s().p("AgCATQgEgCgCgDIgFgGIgCgHQgBgEABgFQABgFACgDQADgFAFAAQAEgBAEAEQAFACADAEQADAEABAFQABADgBAEQgBAGgEADQgFACgDgCIgCgCIAAgBIgBgCIgCABIgDgBIgCgDIgCgEIABgEIACgGIAEgDQABAAAAAAQABAAAAAAQAAAAAAAAQABAAABABIACACIABAFIACgEIAEACIgGAMIgBACIgBACIABAAIADAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBABAAIABgFQABgDgBgDQgBgEgCgDQgCgEgEgCQgEgCgDAAQgEABgCADQgCADgCAEQgBAFABAEQABAFAEADIAHAGQADADADAAQAEAAACgCIADACIgEADIgGAAQgDAAgDgDgAAAgIIgCAAIgDADIAAADQgBABAAABQAAAAAAAAQAAAAAAABQAAABABAAQAAABAAAAQAAABAAAAQAAAAABABQAAAAAAAAIACABIACgBIADgCIAAgDIAAgFIgBgDIgCgBIAAABg");
	this.shape_310.setTransform(1685.35,539.1889);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#FFFFFF").s().p("AABAQIgEgBQgEgCgBgDQgCgDABgDIADACIAAADIAEADQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgFQgCACgCgCQgEgCgCgEIAAgIIACgFQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBIADABQADACACAEIAAgCIADACIgEARQgBAFgBACIgDACIAAgBgAgBgLQgCABgBAEQgBAEABACIADAEQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQACgCABgDQABgEgBgCQgBgDgCgBIgCgBIgBABg");
	this.shape_311.setTransform(1681.5688,537.355);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#FFFFFF").s().p("AgEAAIABgEIAIAFIAAADg");
	this.shape_312.setTransform(1680.1,536.05);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#FFFFFF").s().p("AgEAOIAFgdIAEACIgFAdg");
	this.shape_313.setTransform(1678.225,534.55);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#FFFFFF").s().p("AgEAOIAFgdIAEACIgFAdg");
	this.shape_314.setTransform(1677.475,534.1);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#FFFFFF").s().p("AADAMIAAgDIgDABIgDgBQgDgCgBgDQgBgDAAgBIABgDIACgBIADAAIACABIAGACIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgDgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCACIgDgCIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQABAAAAAAIADABIAEADIABADIABADIAAADIgBAEIgCAHIABADgAgEAAIgBABIABACIACADIACABQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBIACgDIAAgBIgFgBIgCAAIgCAAg");
	this.shape_315.setTransform(1676.0313,533.8917);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#FFFFFF").s().p("AgBAOIgCgCIgBgCIABgFIACgLIgCgBIAAgDIADABIAAgFIAEAAIgCAHIADACIAAACIgEgBIgCALIAAACIAAACIABABIABAAIAAADIgCgBg");
	this.shape_316.setTransform(1674.8,532.7);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#FFFFFF").s().p("AgBALQgDgCgBgDQgCgCAAgEIADABIABAEIADADIACABQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAgBIgBgCIgCgDIgEgEIgCgDIAAgDIACgDIABgBIACAAIACABIAEAEIACADIAAAEIgDgCIgBgDIgCgCQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAACIABABIABADIAFADIABADIAAADIgCADIgDABIgBABIgCgCg");
	this.shape_317.setTransform(1673.245,532.1063);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_318.setTransform(1671.425,531.075);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#FFFFFF").s().p("AgDAOIADgVIADACIgEAVgAAAgLIABgDIAEABIgBAEg");
	this.shape_319.setTransform(1670.2,529.9);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#FFFFFF").s().p("AAHAQIADgOIABgCIgCgCIgBgCQAAAAgBAAQAAgBgBAAQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAABAAAAQgBABAAABIgCALIgCgBIACgNQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAIgDAAIgCABIgBAEIgDAKIgDgBIAFgVIACACIAAADIADgCIADABIACADIABAEQADgDADACQADACABADQABACgBADIgDAPg");
	this.shape_320.setTransform(1667.27,528.725);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#FFFFFF").s().p("AgJAOIAGgcIADABIgBADQAAAAABgBQAAAAAAAAQAAAAAAAAQABgBAAAAIADABIAEAFIACAFIgBAFQAAAEgCABQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBABIgDgBIgCgDQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgCAKgAAAgHQgCABgBAEQAAADABADQABACABABQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACAAAAgFQABgDgBgDQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBAAIgCgBIgBABg");
	this.shape_321.setTransform(1664.8333,527.4);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#FFFFFF").s().p("AADANIACgNIABgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAABAAAAQgCAAAAAFIgDAKIgDgBIAFgVIACACIAAADQABgDAEACIADADIACADIAAADIgBADIgCANg");
	this.shape_322.setTransform(1662.975,526.225);

	var maskedShapeInstanceList = [this.shape_251,this.shape_252,this.shape_253,this.shape_254,this.shape_255,this.shape_256,this.shape_257,this.shape_258,this.shape_259,this.shape_260,this.shape_261,this.shape_262,this.shape_263,this.shape_264,this.shape_265,this.shape_266,this.shape_267,this.shape_268,this.shape_269,this.shape_270,this.shape_271,this.shape_272,this.shape_273,this.shape_274,this.shape_275,this.shape_276,this.shape_277,this.shape_278,this.shape_279,this.shape_280,this.shape_281,this.shape_282,this.shape_283,this.shape_284,this.shape_285,this.shape_286,this.shape_287,this.shape_288,this.shape_289,this.shape_290,this.shape_291,this.shape_292,this.shape_293,this.shape_294,this.shape_295,this.shape_296,this.shape_297,this.shape_298,this.shape_299,this.shape_300,this.shape_301,this.shape_302,this.shape_303,this.shape_304,this.shape_305,this.shape_306,this.shape_307,this.shape_308,this.shape_309,this.shape_310,this.shape_311,this.shape_312,this.shape_313,this.shape_314,this.shape_315,this.shape_316,this.shape_317,this.shape_318,this.shape_319,this.shape_320,this.shape_321,this.shape_322];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251}]},21).to({state:[]},42).to({state:[]},10).wait(27));

	// Screen
	this.instance_21 = new lib.Tween1("synched",0);
	this.instance_21.setTransform(1709.95,586.75);
	this.instance_21.alpha = 0;
	this.instance_21._off = true;

	this.instance_22 = new lib.Tween2("synched",0);
	this.instance_22.setTransform(1709.95,586.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_21}]},12).to({state:[{t:this.instance_22}]},6).to({state:[{t:this.instance_22}]},81).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(12).to({_off:false},0).to({_off:true,alpha:1},6).wait(82));

	// Layer_2
	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#FFFFFF").s().p("Ah7B8IAAj3ID3AAIAAD3g");
	this.shape_323.setTransform(11.65,10);

	this.timeline.addTween(cjs.Tween.get(this.shape_323).wait(100));

	// Layer_1
	this.instance_23 = new lib.ClipGroup();
	this.instance_23.setTransform(1262.3,584.1,1,1,0,0,0,1262.3,689.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(100));

	// stageBackground
	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EjG5hc9MGNzAAAMAAAC57MmNzAAAg");
	this.shape_324.setTransform(1263,585);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#FFFFFF").s().p("EjG5Bc+MAAAi57MGNzAAAMAAAC57g");
	this.shape_325.setTransform(1263,585);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_325},{t:this.shape_324}]}).wait(100));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(1262.3,480,1262.3,793.3);
// library properties:
lib.properties = {
	id: '1D6C9FB9DE14B04EA5EB2B829FFB4D28',
	width: 2526,
	height: 1170,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Image.png", id:"Image"},
		{src:"images/Path.png", id:"Path"},
		{src:"images/Path_0.png", id:"Path_0"},
		{src:"images/Path_1.png", id:"Path_1"},
		{src:"images/Path_2.png", id:"Path_2"},
		{src:"images/Path_3.png", id:"Path_3"},
		{src:"images/Path_4.png", id:"Path_4"},
		{src:"images/Path_5.png", id:"Path_5"},
		{src:"images/Path_6.png", id:"Path_6"},
		{src:"images/Path_7.png", id:"Path_7"},
		{src:"images/Path_8.png", id:"Path_8"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['1D6C9FB9DE14B04EA5EB2B829FFB4D28'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;